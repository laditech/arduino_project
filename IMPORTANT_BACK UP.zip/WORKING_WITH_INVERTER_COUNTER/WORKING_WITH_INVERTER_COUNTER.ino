//Arduino Timer Relay - Triger relay for specific time

#include <LiquidCrystal_I2C.h>  //https://github.com/fdebrabander/Arduino-LiquidCrystal-I2C-library
//LiquidCrystal_I2C lcd(0x3F, 16, 2);  // LCD HEX address 0x3F -- change according to yours
LiquidCrystal_I2C lcd(0x20, 20, 4);
#include "Countimer.h" //https://github.com/inflop/Countimer
Countimer tdown;
#include <EEPROM.h>

#define bt_set    3 //A3
#define bt_up     4 //A2
#define bt_down   5 //A1
#define bt_start  6 //A0

#define SOL_ADC A3     // Solar panel side voltage divider is connected to pin A0 
#define BAT_ADC A2 

int time_s = 0;
int time_m = 0;
int time_h = 0;
int set = 0;
int flag1=0, flag2=0;

int relay = 9;
int buzzer = 10;

int cnt_st=0;

void setup() {
Serial.begin (9600);

pinMode(bt_set,   INPUT_PULLUP);
pinMode(bt_up,    INPUT_PULLUP);
pinMode(bt_down,  INPUT_PULLUP);
pinMode(bt_start, INPUT_PULLUP);

pinMode(relay, OUTPUT);
pinMode(buzzer, OUTPUT);

  
  lcd.init();    
//lcd.begin();
lcd.clear();
lcd.setCursor(0,0);
lcd.print("   Welcome To   ");
lcd.setCursor(0,1);
lcd.print("Countdown  Timer");
tdown.setInterval(print_time, 999);
eeprom_read();
delay(1000);
lcd.clear();
}

void print_time(){
time_s = time_s-1;
if(time_s<0){time_s=59; time_m = time_m-1;}
if(time_m<0){time_m=59; time_h = time_h-1;}
}

void tdownComplete(){Serial.print("ok");}

//tdown.stop(); 

void loop()
{
tdown.run();

if(digitalRead (bt_set) == 0)

{
  
if(flag1==0 && flag2==0)
{

flag1=1;
set = set+1;
if(set>3){set=0;}
delay(100); 
}

}

else{flag1=0;}

if(digitalRead (bt_up) == 0)
{
//if(set==0){tdown.start(); flag2=1;}    // to be uncomment
if(set==1){time_s++;}
if(set==2){time_m++;}
if(set==3){time_h++;}
if(time_s>59){time_s=0;}
if(time_m>59){time_m=0;}
if(time_h>99){time_h=0;}
if(set>0){eeprom_write(); Serial.println(" saving..");
//
delay(100);
//lcd.clear();
////
//lcd.print("saving ..up");

}
delay(200); 

}

if(digitalRead (bt_down) == 0){
if(set==0){tdown.stop(); flag2=0;}
if(set==1){time_s--;}
if(set==2){time_m--;}
if(set==3){time_h--;}
if(time_s<0){time_s=59;}
if(time_m<0){time_m=59;}
if(time_h<0){time_h=99;}
if(set>0){eeprom_write();}
delay(200); 
}

if(digitalRead (bt_start) == 0)
{ 
  delay(700);
  cnt_st++;
  flag2=1;
  flag1=0; // NOT THERE BEFORE
  lcd.setCursor(0,0);
//if(set==0 && flag2==1){lcd.print("      MMTimer     ");}
  if(set==0 && cnt_st==1)
  
  {
  eeprom_read(); 
  digitalWrite(relay, HIGH); 
 // tdown.restart(); 
  //
  tdown.start();


   lcd.clear();
   lcd.setCursor(0,0);
  
//  if(set==0 && cnt_st==1)
//  
//  {
    lcd.print("Timer STARTED");
    
  }

 // else
  if(set==0 && cnt_st==2)
  {
   // 
   //tdown.restart(); 
  // tdown.pause();

           // 
           //tUp.pause();
        tdown.pause();
//        tnone.pause();
   
   // tdown.stop(); 
   
    lcd.setCursor(0,0);
    lcd.print("Timer STOP/DISABLE");
 lcd.setCursor(1,14);
 //lcd.clear();
   // 
   lcd.print("        RERERERERERERE      .");
     cnt_st = 0;
  }
}

lcd.setCursor(0,0);
if(set==0 && flag2==0){lcd.print("SET TIME       ");}
if(set==1 ){lcd.print("  Set Timer SS  ");}
if(set==2){lcd.print("  Set Timer MM  ");}
if(set==3){lcd.print("  Set Timer HH  ");}

lcd.setCursor(4,1);
if(time_h<=9){lcd.print("0");}
lcd.print(time_h);
lcd.print(":");
if(time_m<=9){lcd.print("0");}
lcd.print(time_m);
lcd.print(":");
if(time_s<=9){lcd.print("0");}
lcd.print(time_s);
lcd.print("   ");

if(time_s==0 && time_m==0 && time_h==0 && flag2==1)
{

flag2=0;
tdown.stop(); 
//tdown.pause(); 
digitalWrite(relay, LOW);
digitalWrite(buzzer, HIGH);
delay(300);
lcd.setCursor(0,0);
lcd.print("TIME ELASPES,OFF");
digitalWrite(buzzer, LOW);
delay(200);
digitalWrite(buzzer, HIGH);
delay(300);
digitalWrite(buzzer, LOW);
delay(200);
digitalWrite(buzzer, HIGH);
delay(300);
digitalWrite(buzzer, LOW);
}

if(flag2==1)
{

lcd.setCursor(0,2);
lcd.print(cnt_st);
digitalWrite(relay, HIGH);
  
  }


else{digitalWrite(relay, LOW);}

delay(1);
//Serial.println(cnt_st);
}

void eeprom_write(){
EEPROM.write(1, time_s);  
EEPROM.write(2, time_m);  
EEPROM.write(3, time_h);  
}

void eeprom_read(){
time_s =  EEPROM.read(1);
time_m =  EEPROM.read(2);
time_h =  EEPROM.read(3);
}
