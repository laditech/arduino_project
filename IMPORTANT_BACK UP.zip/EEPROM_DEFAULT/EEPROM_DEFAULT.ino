//
#include <EEPROM.h>
//#include <FlashStorage_SAMD.h>
#include <SoftwareSerial.h>

//
String stat = "";
String dateingy1 = "";
String dateingy2 = "";
String dateingy3 = "";
String dateingy4 = "";

String dateingy1sp = "";
String dateingy2sp = "";
String dateingy3sp = "";
String dateingy4sp = "";

String dateingm1 = "";
String dateingm2 = "";
String dateingm3 = "";
String dateingm4 = "";


String dateingm1sp = "";
String dateingm2sp = "";
String dateingm3sp = "";
String dateingm4sp = "";




String dateingd1 = "";
String dateingd2 = "";
String dateingd3 = "";
String dateingd4 = "";

String dateingd1sp = "";
String dateingd2sp = "";
String dateingd3sp = "";
String dateingd4sp = "";



String houring1 = "";
String houring2 = "";
String houring3 = "";
String houring4 = "";

String houring1sp = "";
String houring2sp = "";
String houring3sp = "";
String houring4sp = "";


String mining1 = "";
String mining2 = "";
String mining3 = "";
String mining4 = "";

String mining1sp = "";
String mining2sp = "";
String mining3sp = "";
String mining4sp = "";

String secing1 = "";
String secing2 = "";
String secing3 = "";
String secing4 = "";

String secing1sp = "";
String secing2sp = "";
String secing3sp = "";
String secing4sp = "";


//String dateingm = "";
//String dateingd = "";
//String houring = "";
//String mining = "";
//String secing = "";

//String phone4 = "";
//String id = "";
//String password ="";
#define MAX_PS  "PASSWORD NOT WITHIN RANGE"
//#define CH_PH1   0
//#define CH_PH2   15
//#define CH_PH3   30
//#define CH_PS1    45
//#define CH_PD1    50
//#define CH_ST1    58 //address
  
#define CH_Y1    0     //10        // START CH1
#define CH_M1    5     //10
#define CH_D1    8     //10  7
#define CH_H1    11    //50
#define CH_MI1    14 //message 2
#define CH_S1   17  //138

#define CH_Y1SP    20     //10
#define CH_M1SP    25     //10
#define CH_D1SP    28     //10        //STOP CH1
#define CH_H1SP    31    //50
#define CH_MI1SP   34 //message 2
#define CH_S1SP    37 //138

#define CH_Y2    40     //10 36
#define CH_M2    45     //10        // START CH2
#define CH_D2    48     //10
#define CH_H2    51    //50
#define CH_MI2   54 //message 2    // MISTAKE CORRECT
#define CH_S2    57 //138

#define CH_Y2SP    60     //10
#define CH_M2SP    65     //10
#define CH_D2SP    68     //10
#define CH_H2SP    71    //50
#define CH_MI2SP   74 //message 2
#define CH_S2SP    77 //138

#define CH_Y3    80     //10 
#define CH_M3    85     //10
#define CH_D3    88     //10
#define CH_H3    91    //50
#define CH_MI3   94 //message 2
#define CH_S3    97  //138

#define CH_Y3SP    100     //10
#define CH_M3SP    105     //10
#define CH_D3SP    108     //10
#define CH_H3SP    111    //50
#define CH_MI3SP   114 //message 2
#define CH_S3SP    117 //138

#define CH_Y4    120     //10
#define CH_M4    125     //10
#define CH_D4    128     //10
#define CH_H4    131    //50
#define CH_MI4   134 //message 2
#define CH_S4    137  //138

#define CH_Y4SP    140     //10
#define CH_M4SP    145     //10
#define CH_D4SP    148     //10
#define CH_H4SP    151    //50
#define CH_MI4SP   154 //message 2
#define CH_S4SP    157  //138

char dd1[]="12";
char dm1[]="23";
char dy1[]="2021";

char dd1sp[]="25";
char dm1sp[]="23";
char dy1sp[]="2001";

char dd2[]="19";
char dm2[]="23";
char dy2[]="2022";

char dd2sp[]="20";
char dm2sp[]="23";
char dy2sp[]="2002";

char dd3[]="27";
char dm3[]="23";
char dy3[]="2023";

char dd3sp[]="29";
char dm3sp[]="23";
char dy3sp[]="2003";

char dd4[]="27";
char dm4[]="23";
char dy4[]="2024";

char dd4sp[]="21";
char dm4sp[]="23";
char dy4sp[]="2004";

String alldate="";

char h1[]="1";  
char m1[]="30";  
char s1[]="25"; 

char h1sp[]="3";  
char m1sp[]="30";  
char s1sp[]="25"; 

char h2[]="1";  
char m2[]="30";  
char s2[]="25"; 

char h2sp[]="5";  
char m2sp[]="30";  
char s2sp[]="25"; 

char h3[]="1";  
char m3[]="36";  
char s3[]="25"; 

char h3sp[]="1";  
char m3sp[]="33";  
char s3sp[]="25"; 

char h4[]="1";  
char m4[]="30";  
char s4[]="25"; 

char h4sp[]="1";  
char m4sp[]="30";  
char s4sp[]="25"; 

int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////

int l_dy1;
int l_dd1;
int l_dm1;
int l_h1;
int l_m1;
int l_s1; //57;

int l_dy2;
int l_dd2;
int l_dm2;
int l_h2;
int l_m2;
int l_s2; //57;

int l_dy3;
int l_dd3;
int l_dm3;
int l_h3;
int l_m3;
int l_s3; //57;


int l_dy4;
int l_dd4;
int l_dm4;
int l_h4;
int l_m4;
int l_s4; //57;


int l_dy1sp;
int l_dd1sp;
int l_dm1sp;
int l_h1sp;
int l_m1sp;
int l_s1sp; //57;

int l_dy2sp;
int l_dd2sp;
int l_dm2sp;
int l_h2sp;
int l_m2sp;
int l_s2sp; //57;

int l_dy3sp;
int l_dd3sp;
int l_dm3sp;
int l_h3sp;
int l_m3sp;
int l_s3sp; //57;

int l_dy4sp;
int l_dd4sp;
int l_dm4sp;
int l_h4sp;
int l_m4sp;
int l_s4sp; //57;


void setup() {

Serial.begin(9600);
E_clear(0, EEPROM.length());
delay(500);

String chh="CH";
int tt=2;
chh+=2;

l_dy1=String(dy1).length();
l_dy1sp=String(dy1sp).length();
l_dy2=String(dy2).length();
l_dy2sp=String(dy2sp).length();
Serial.println(l_dy2sp);
l_dy3=String(dy3).length();
l_dy3sp=String(dy3sp).length();
l_dy4=String(dy4).length();
l_dy4sp=String(dy4sp).length();

l_dm1=String(dm1).length();
l_dm2=String(dm2).length();
l_dm3=String(dm3).length();
l_dm4=String(dm4).length();

l_dm1sp=String(dm1sp).length();
l_dm2sp=String(dm2sp).length();
l_dm3sp=String(dm3sp).length();
l_dm4sp=String(dm4sp).length();

l_dd1=String(dd1).length();
l_dd2=String(dd2).length();
l_dd3=String(dd3).length();
l_dd4=String(dd4).length();

l_dd1sp=String(dd1sp).length();
l_dd2sp=String(dd2sp).length();
l_dd3sp=String(dd3sp).length();
l_dd4sp=String(dd4sp).length();

l_h1=String(h1).length();
l_h2=String(h2).length();
l_h3=String(h3).length();
l_h4=String(h4).length();

l_h1sp=String(h1sp).length();
l_h2sp=String(h2sp).length();
l_h3sp=String(h3sp).length();
l_h4sp=String(h4sp).length();

l_m1 =String(m1).length();
l_m2 =String(m2).length();
l_m3 =String(m3).length();
l_m4 =String(m4).length();

l_m1sp =String(m1sp).length();
l_m2sp =String(m2sp).length();
l_m3sp =String(m3sp).length();
l_m4sp =String(m4sp).length();

l_s1 =String(s1).length(); 
l_s2 =String(s2).length(); 
l_s3 =String(s3).length(); 
l_s4 =String(s4).length(); 

l_s1sp =String(s1sp).length(); 
l_s2sp =String(s2sp).length(); 
l_s3sp =String(s3sp).length(); 
l_s4sp =String(s4sp).length(); 

Serial.println("YEAR DAY1:");
Serial.print(dy1);
save_id(dy1,CH_Y1 ,l_dy1+CH_Y1);
save_id(dy2,CH_Y2 ,l_dy2+CH_Y2);
save_id(dy3,CH_Y3 ,l_dy3+CH_Y3);
save_id(dy4,CH_Y4 ,l_dy4+CH_Y4);

save_id(dd1,CH_D1 ,l_dd1+CH_D1);
save_id(dd2,CH_D2 ,l_dd2+CH_D2);
save_id(dd3,CH_D3 ,l_dd3+CH_D3);
save_id(dd4,CH_D4 ,l_dd4+CH_D4);
//
//

save_id(dm1,CH_M1 ,l_dm1+CH_M1);
save_id(dm2,CH_M2 ,l_dm2+CH_M2);
save_id(dm3,CH_M3 ,l_dm3+CH_M3);
save_id(dm4,CH_M4 ,l_dm4+CH_M4);

 
save_id(m1,CH_MI1 ,l_m1+CH_MI1);
save_id(m2,CH_MI2 ,l_m2+CH_MI2);
save_id(m3,CH_MI3 ,l_m3+CH_MI3);
save_id(m4,CH_MI4 ,l_m4+CH_MI4);


save_id(h1,CH_H1 ,l_h1+CH_H1);
save_id(h2,CH_H2 ,l_h2+CH_H2);
save_id(h3,CH_H3 ,l_h3+CH_H3);
save_id(h4,CH_H4 ,l_h4+CH_H4);


save_id(s1,CH_S1 ,l_s1+CH_S1);
save_id(s2,CH_S2 ,l_s2+CH_S2);
save_id(s3,CH_S3 ,l_s3+CH_S3);
save_id(s4,CH_S4 ,l_s4+CH_S4);

save_id(dy1sp,CH_Y1SP ,l_dy1sp+CH_Y1SP);
save_id(dy2sp,CH_Y2SP ,l_dy2sp+CH_Y2SP);
save_id(dy3sp,CH_Y3SP ,l_dy3sp+CH_Y3SP);
save_id(dy4sp,CH_Y4SP ,l_dy4sp+CH_Y4SP);

//
save_id(dm1sp,CH_M1SP ,l_dm1sp+CH_M1SP);
save_id(dm2sp,CH_M2SP ,l_dm2sp+CH_M2SP);
save_id(dm3sp,CH_M3SP ,l_dm3sp+CH_M3SP);
save_id(dm4sp,CH_M4SP ,l_dm4sp+CH_M4SP);


save_id(dd1sp,CH_D1SP ,l_dd1sp+CH_D1SP);
save_id(dd2sp,CH_D2SP ,l_dd2sp+CH_D2SP);
save_id(dd3sp,CH_D3SP ,l_dd3sp+CH_D3SP);
save_id(dd4sp,CH_D4SP ,l_dd4sp+CH_D4SP);

save_id(h1sp,CH_H1SP ,l_h1sp+CH_H1SP);
save_id(h2sp,CH_H2SP ,l_h2sp+CH_H2SP);
save_id(h3sp,CH_H3SP ,l_h3sp+CH_H3SP);
save_id(h4sp,CH_H4SP ,l_h4sp+CH_H4SP);

save_id(m1sp,CH_MI1SP ,l_m1sp+CH_MI1SP);
save_id(m2sp,CH_MI2SP ,l_m2sp+CH_MI2SP);
save_id(m3sp,CH_MI3SP ,l_m3sp+CH_MI3SP);
save_id(m4sp,CH_MI4SP ,l_m4sp+CH_MI4SP);

save_id(s1sp,CH_S1SP ,l_s1sp+CH_S1SP);
save_id(s2sp,CH_S2SP ,l_s2sp+CH_S2SP);
save_id(s3sp,CH_S3SP ,l_s3sp+CH_S3SP);
save_id(s4sp,CH_S4SP ,l_s4sp+CH_S4SP);


dateingy1  = read_it(CH_Y1,l_dy1+CH_Y1); 
dateingy2  = read_it(CH_Y2,l_dy2+CH_Y2); 
dateingy3  = read_it(CH_Y3,l_dy3+CH_Y3); 
dateingy4  = read_it(CH_Y4,l_dy4+CH_Y4); 

dateingy1sp  = read_it(CH_Y1SP,l_dy1sp+CH_Y1SP);
dateingy2sp  = read_it(CH_Y2SP,l_dy2sp+CH_Y2SP);
dateingy3sp  = read_it(CH_Y3SP,l_dy3sp+CH_Y3SP);
dateingy4sp  = read_it(CH_Y4SP,l_dy4sp+CH_Y4SP);


dateingm1  = read_it(CH_M1,l_dm1+CH_M1); 
dateingm2  = read_it(CH_M2,l_dm2+CH_M2); 
dateingm3  = read_it(CH_M3,l_dm3+CH_M3);
dateingm4  = read_it(CH_M4,l_dm4+CH_M4);  

dateingm1sp  = read_it(CH_M1SP,l_dm1sp+CH_M1SP); 
dateingm2sp  = read_it(CH_M2SP,l_dm2sp+CH_M2SP); 
dateingm3sp  = read_it(CH_M3SP,l_dm3sp+CH_M3SP);
dateingm4sp  = read_it(CH_M4SP,l_dm4sp+CH_M4SP);  


dateingd1  = read_it(CH_D1,l_dd1+CH_D1); 
dateingd2  = read_it(CH_D2,l_dd2+CH_D2); 
dateingd3  = read_it(CH_D3,l_dd3+CH_D3); 
dateingd4  = read_it(CH_D4,l_dd4+CH_D4); 

dateingd1sp  = read_it(CH_D1SP,l_dd1sp+CH_D1SP); 
dateingd2sp  = read_it(CH_D2SP,l_dd2sp+CH_D2SP); 
dateingd3sp  = read_it(CH_D3SP,l_dd3sp+CH_D3SP); 
dateingd4sp  = read_it(CH_D4SP,l_dd4sp+CH_D4SP); 


houring1  = read_it(CH_H1,l_h1+CH_H1); 
houring2  = read_it(CH_H2,l_h2+CH_H2);
houring3  = read_it(CH_H3,l_h3+CH_H3);
houring4  = read_it(CH_H4,l_h4+CH_H4);


houring1sp  = read_it(CH_H1SP,l_h1sp+CH_H1SP); 
houring2sp  = read_it(CH_H2SP,l_h2sp+CH_H2SP);
houring3sp  = read_it(CH_H3SP,l_h3sp+CH_H3SP);
houring4sp  = read_it(CH_H4SP,l_h4sp+CH_H4SP);


mining1  = read_it(CH_MI1,l_m1+CH_MI1);
mining2  = read_it(CH_MI2,l_m2+CH_MI2);
mining3  = read_it(CH_MI3,l_m3+CH_MI3);
mining4  = read_it(CH_MI4,l_m4+CH_MI4);


mining1sp  = read_it(CH_MI1SP,l_m1sp+CH_MI1SP);
mining2sp  = read_it(CH_MI2SP,l_m2sp+CH_MI2SP);
mining3sp  = read_it(CH_MI3SP,l_m3sp+CH_MI3SP);
mining4sp  = read_it(CH_MI4SP,l_m4sp+CH_MI4SP);


secing1  = read_it(CH_S1,l_s1+CH_S1); 
secing2  = read_it(CH_S2,l_s2+CH_S2);
secing3  = read_it(CH_S3,l_s3+CH_S3); 
secing4  = read_it(CH_S4,l_s4+CH_S4); 

secing1sp  = read_it(CH_S1SP,l_s1sp+CH_S1SP); 
secing2sp  = read_it(CH_S2SP,l_s2sp+CH_S2SP);
secing3sp  = read_it(CH_S3SP,l_s3sp+CH_S3SP); 
secing4sp  = read_it(CH_S4SP,l_s4sp+CH_S4SP); 

delay(500);

Serial.println("DATE-Y1 START:" +dateingy1+ "");
Serial.println("DATE-Y2 START:" +dateingy2+ "");
Serial.println("DATE-Y3 START:" +dateingy3+ "");
Serial.println("DATE-Y4 START:" +dateingy4+ "");

Serial.println("DATE-Y1 STOP:" +dateingy1sp+ "");
Serial.println("DATE-Y2 STOP:" +dateingy2sp+ "");
Serial.println("DATE-Y3 STOP:" +dateingy3sp+ "");
Serial.println("DATE-Y4 STOP:" +dateingy4sp+ "");

Serial.println("DATE-M START:" +dateingm1+ "");
Serial.println("DATE-M START:" +dateingm2+ "");
Serial.println("DATE-M START:" +dateingm3+ "");
Serial.println("DATE-M START:" +dateingm4+ "");

Serial.println("DATE-M1 STOP:" +dateingm1sp+ "");
Serial.println("DATE-M2 STOP:" +dateingm2sp+ "");
Serial.println("DATE-M3 STOP:" +dateingm3sp+ "");
Serial.println("DATE-M4 STOP:" +dateingm4sp+ "");

//////////////////////////////////////////////////////////////////////////////////////////////////
Serial.println("DATE-D1 START:" +dateingd1+ "");
Serial.println("DATE-D2 START:" +dateingd2+ "");
Serial.println("DATE-D3 START:" +dateingd3+ "");
Serial.println("DATE-D4 START:" +dateingd4+ "");

Serial.println("DATE-D1 STOP:" +dateingd1sp+ "");
Serial.println("DATE-D2 SOP:" +dateingd2sp+ "");
Serial.println("DATE-D3 STOP:" +dateingd3sp+ "");
Serial.println("DATE-D4 STOP:" +dateingd4sp+ "");

Serial.println("HOUR-1 START:" +houring1+ "");
Serial.println("HOUR-2 START:" +houring2+ "");
Serial.println("HOUR-3 START:" +houring3+ "");
Serial.println("HOUR-4 START:" +houring4+ "");

Serial.println("HOUR-1 STOP:" +houring1sp+ "");
Serial.println("HOUR-2 STOP:" +houring2sp+ "");
Serial.println("HOUR-3 STOP:" +houring3sp+ "");
Serial.println("HOUR-4 STOP:" +houring4sp+ "");


Serial.println("MINUTE-1 START:" +mining1+ "");
Serial.println("MINUTE-2 START:" +mining2+ "");
Serial.println("MINUTE-3 START:" +mining3+ "");
Serial.println("MINUTE-4 START:" +mining4+ "");

Serial.println("MINUTE-1 STOP:" +mining1sp+ "");
Serial.println("MINUTE-2 STOP:" +mining2sp+ "");
Serial.println("MINUTE-3 STOP:" +mining3sp+ "");
Serial.println("MINUTE-4 STOP:" +mining4sp+ "");

Serial.println("SECONDS-1 START:" +secing1+ "");
Serial.println("SECONDS-2 START:" +secing2+ "");
Serial.println("SECONDS-3 START:" +secing3+ "");
Serial.println("SECONDS-4 START:" +secing4+ "");


Serial.println("SECONDS-1 STOP:" +secing1sp+ "");
Serial.println("SECONDS-2 STOP:" +secing2sp+ "");
Serial.println("SECONDS-3 STOP:" +secing3sp+ "");
Serial.println("SECONDS-4 STOP:" +secing4sp+ "");
  
}

void loop() {


}











void save_id(char id[],int sta, int clen)
{
int t= 0;
for(int i = sta; i < clen+1; i++)
  {
    // 
  //  Serial.println(i);
    
        EEPROM.put(i, id[t++]);

     //delay(500);
       success = 1; 

 
     
    }


  
}


 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }
//     EEPROM.commit(); 
  }




String read_it(int sta, int clen)
{
   char inprom1;
  String inRprom1 = "";
for(int i = sta; i < clen; i++){
  
    
 
   inprom1 = EEPROM.read(i);
   
   inRprom1.concat(inprom1);
}

if(inRprom1.length()>0)
{
return inRprom1;

}

}
