
#define B1  9
#define B2  10
#define sw 8  // power on switch
#define batteryVoltage 0  // A0
#define load 1  // A1
#define temp 2  // A2
#define fv 4  // A4
#define buzzer 13
#define fan 7
#define HVON  6 // high voltage indicator led

int x = 0;  int y = 0; int z = 0;
int ton,toff,fb,bv,lc,ol;
void setup() {                

  pinMode(B1, OUTPUT); 
  pinMode(B2, OUTPUT);  

  pinMode(sw, INPUT); //  switch
pinMode(buzzer, OUTPUT);
  
  pinMode(HVON, OUTPUT);
  digitalWrite(HVON, LOW);
  


  pinMode(fan, OUTPUT);
  digitalWrite(fan, LOW);
  ol=0;
}

void loop() {
 bv= analogRead(batteryVoltage);
    bv= map(bv, 0, 1023, 0, 40);

     lc= analogRead(load); 
   
     if(lc>10){
      
       ol=1;
      }
while(ol){
    digitalWrite(buzzer, HIGH); 
  delay(400);
   digitalWrite(buzzer, LOW); 
    delay(600);
  if(digitalRead(sw)){
      ol=0;
    }
  }
// turn off the fan:
digitalWrite(fan, LOW); 

     
  if ((digitalRead(sw) == 0) && (bv > 9)&&lc<10)  {   
// check for closed enable switch, battery state
    SoftStart();  // bring power up slowly
    while ((digitalRead(sw) == 0) && (bv > 9)&&lc<10)   {
// turn on the fan:
        digitalWrite(fan, HIGH); 
// read battery voltage:
       bv= analogRead(batteryVoltage);
    bv= map(bv, 0, 1023, 0, 40);
    // read load current:
  lc= analogRead(load);
     
  // read feedback value:
 fb = analogRead(fv);
   fb = map(fb, 0, 1023, 1297, 0);
   fb =fb -115;
   if(fb>900){
    fb=900;
    }
  if(fb<110){
    fb=110;
    }
ton=1000-fb;
toff=1000-ton;

      
      digitalWrite(B1, HIGH);   // B1 on
      delayMicroseconds(ton*10);
      digitalWrite(B1, LOW);  // B1 off
delayMicroseconds(toff*10);
      digitalWrite(B2, HIGH);   // B2 on
    delayMicroseconds(ton*10);
      
      digitalWrite(B2, LOW);  // B2 off
delayMicroseconds(toff*10);



      x++;
      if (x == 20) { // flash HVON LED
        toggle(HVON);
        y = analogRead(0); 
        x=0;

       
      } // end 2nd if

    } // end while

  } // 

}  // end loop


void toggle(int pinNum) {  
// toggle the state on a pin

  int pinState = digitalRead(pinNum);
  pinState = !pinState;
  digitalWrite(pinNum, pinState); 
}

//SoftStart allows power to come up slowly to prevent excessive surges
// time is about 2 seconds


void SoftStart(void)   {
  digitalWrite(buzzer, HIGH); 
  delay(800);
   digitalWrite(buzzer, LOW); 
  int y = 1;
  int x = 0;
  int z = 9;
  while (y < 9)   {

    digitalWrite(B1, HIGH);   // B1 on
    delay(y);  // wait for 8.3 mS
    digitalWrite(B1, LOW);  // B1 off
    delay(z);
    digitalWrite(B2, HIGH);   // B2 on
    delay(y);  // wait for 8.3 mS
    digitalWrite(B2, LOW);  // B2 off
    delay(z);

    x++;
    if (x == 30) { 
      y = y + 1;
      z = z - 1; 
      x=0;

    }
  }
}
