#define CH_ID    0     //45
#define CH_PS    11    //50
//#define CH_IN    19 //message 9
#define CH_PH   19  //138
//char ph[]="+2348072251601";
//char id[]="HML001";   
//char ps[]="1997";



//char st[]= "I need urgent help, i am in danger  @ LOCATION : http://www.google.com/maps/place/14.114141,15.1111113";


int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////

//int l_id = 10;
//int l_ps = 8;
//int l_ph = 11; //57;
//
//
//void setup() {
//
//Serial.begin(9600);
//
//    E_clear(0, EEPROM.length());
//    delay(50);
//  save_id(id,CH_ID ,l_id+CH_ID);
//  save_id(ps,CH_PS,l_ps+CH_PS);
//  save_id(ph,CH_PH ,l_ph+CH_PH);
//
//
//sid  = read_it(CH_ID,l_id+CH_ID); 
//sps  = read_it(ps,CH_PS,l_ps+CH_PS);
//sph  = read_it(ph,CH_PH ,l_ph+CH_PH);  
//
//
//Serial.println("ID:" +sid+ "");
//Serial.println("PASS:" +sps+ "");
//Serial.println("PHONE:" +sph+ "");
// 
//   
//}
//





 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }
    
  }



void save_id(char id[],int sta, int clen)
{
int t= 0;
    for(int i = sta; i < clen+1; i++)
    
    {
         EEPROM.put(i, id[t++]);
         success = 1; 
     }

}



String read_it(int sta, int clen)
{
  char inprom1;
  String inRprom1 = "";

for(int i = sta; i < clen; i++)

{

   inprom1 = EEPROM.read(i);
   inRprom1.concat(inprom1);

}

if(inRprom1.length()>0)
{
return inRprom1;

}

}
