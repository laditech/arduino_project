//Arduino Timer Relay - Triger relay for specific time

#include <LiquidCrystal_I2C.h>  //https://github.com/fdebrabander/Arduino-LiquidCrystal-I2C-library
//LiquidCrystal_I2C lcd(0x3F, 16, 2);  // LCD HEX address 0x3F -- change according to yours
LiquidCrystal_I2C lcd(0x20, 20, 4);
#include "Countimer.h" //https://github.com/inflop/Countimer
Countimer tdown;
#include <EEPROM.h>

#define bt_set    3 //A3
#define bt_up     4 //A2
#define bt_down   5 //A1
#define bt_start  6 //A0
#define BAT_MIN   8.4
#define BAT_MAX   12.6

#define SOL_MIN   12
#define SOL_MAX   15
///////////////////////////////////////////////////////////////////////////////////////NTC/////////////////////////////
//These values are in the datasheet
#define RT0 10000   // Ω
#define B 3977      // K
//--------------------------------------
#define VCC 5    //Supply voltage
#define R 10000  //R=10KΩ
//Variables
float RT, VR, ln, TX, T0, VRT;
/////////////////////////////////////////////////////////////////////////////NTC
#define AVG_NUM 1 //10 
#define BAT_ADC A0 
#define AC_ADC A1     // Solar panel side voltage divider is connected to pin A0 
#define TEMP_ADC A2 
#define SOL_ADC A3     // Solar panel side voltage divider is connected to pin A3 
#define BAT_MIN 8.4  // minimum battery voltage for 12V system
#define BAT_MAX 12.5 //14.5 //15.0  // maximum battery voltage for 12V system
#define BULK_CH_SP 12.6 // bulk charge set point for sealed lead acid battery // flooded type set it to 14.6V
#define FLOAT_CH_SP 11.7  //float charge set point for lead acid battery
#define LVD 8.4        //Low voltage disconnect setting for a 12V system
#define PWM_PIN 10        // pin-3 is used to control the charging MOSFET //the default frequency is 490.20Hz
//
#define LOAD_PIN 13       // pin-13 is used to control the load
//
#define BAT_RED_LED 11
//
#define BAT_GREEN_LED 12
#define SOL_RED_LED 2

//#define LOAD_GREEN_LED 12

int temp_change=0;
float system_volt=0;
float bulk_charge_sp=0;
float float_charge_sp=0;
int charge_stage =0;
float load_status=0;
double PWM_Duty =0; // PWM_Duty varies from 0 to 255
float lvd;

#define FAN_PIN 8
int relay = 7;
int buzzer = 9;

float solar_volt=0;
float bat_volt=0;
float AC_volt=0;
float temperature=0;
int time_s = 0;
int time_m = 0;
int time_h = 0;
int set = 0;
int flag1=0, flag2=0,flag3;


int cnt_st=0;

///////////////////////////////////////////////DISPLAY SPECIAL XTERS////////////////////////////////


byte solar[8] = //icon for solar panel
{
  0b11111,0b10101,0b11111,0b10101,0b11111,0b10101,0b11111,0b00000
};
byte battery[8] =  //icon for battery
{
  0b01110,0b11011,0b10001,0b10001,0b10001,0b10001,0b10001,0b11111
};

byte energy[8] =  // icon for power
{
  0b00010,0b00100,0b01000,0b11111,0b00010,0b00100,0b01000,0b00000
};
/*byte alarm[8] =  // icon for alarm
{
 0b00000,0b00100,0b01110,0b01110,0b01110,0b11111,0b00000,0b00100
};*/
byte temp[8] = //icon for termometer
{
 0b00100,0b01010,0b01010,0b01110,0b01110,0b11111,0b11111,0b01110
};


byte charge[8] = // icon for battery charge
{
  0b01010,0b11111,0b10001,0b10001,0b10001,0b01110,0b00100,0b00100,
};
byte not_charge[8]=
{
  0b00000,0b10001,0b01010,0b00100,0b01010,0b10001,0b00000,0b00000,
};

//////////////////////////////////////////////////////////// FAN/////////////////////////////////////////////////

byte fan_symb[] = {
  B11111,
  B10000,
  B10000,
  B11110,
  B10000,
  B10000,
  B10000,
  B10000
};



/////////////////////////////////////////////////////////END OF FAN LOGO/////////////////////////////////////////


/////////////////////////////////////END OF DISPLAY SPECIAL XTERS/////////////////////////////////////////////////
void print_time(){
time_s = time_s-1;
if(time_s<0){time_s=59; time_m = time_m-1;}
if(time_m<0){time_m=59; time_h = time_h-1;}
}

void tdownComplete()
{
  Serial.print("ok, TIME ELAPSED");

}



void setup() {
Serial.begin (9600);
TCCR2B = TCCR2B & B11111000 | 0x03;    // pin 3 PWM frequency of 980.39 Hz
pinMode(bt_set,   INPUT_PULLUP);
pinMode(bt_up,    INPUT_PULLUP);
pinMode(bt_down,  INPUT_PULLUP);
pinMode(bt_start, INPUT_PULLUP);

pinMode(relay, OUTPUT);
pinMode(buzzer, OUTPUT);
pinMode(FAN_PIN, OUTPUT);
pinMode(LOAD_PIN, OUTPUT);
pinMode(BAT_RED_LED ,OUTPUT);
pinMode(BAT_GREEN_LED,OUTPUT);
pinMode(SOL_RED_LED,OUTPUT);

T0 = 25 + 273.15;   
lcd.init();    
//lcd.begin();


//intro();
///////////////////////////////////////////////////////////////////SET XTER//////////////////////////////////////
lcd.createChar(1,solar);
lcd.createChar(2, battery);
lcd.createChar(3, energy);
//
lcd.createChar(4,temp);
lcd.createChar(5,temp);
lcd.createChar(6,charge);
lcd.createChar(7,not_charge);
lcd.createChar(8, fan_symb);

///////////////////////////////////////////END OF SET XTER////////////////////////////////////////////////////////////////
lcd.clear();
//lcd.setCursor(0,0);

//lcd.print("   Welcome To   ");
//lcd.setCursor(0,1);
//lcd.print("Countdown  Timer");
tdown.setInterval(print_time, 999);
eeprom_read();


///////////////
//
static_icon();



}  // END OF SETUP



void loop()
{
  
  read_data(); 
  read_temp();
  tdown.run();
lcd_display();
system_voltage();        // detect the system voltage according to battery voltage
setpoint();      // decide the charge set point according to system voltage
charge_cycle();         // pwm charging of battery
load_control();         //control the load
led_indication();
monitor_action();


if(digitalRead (bt_set) == 0)
{ 
delay(300);
  
flag1=1;
flag2=0; // not there before

set = set+1;
flag3=0;
if(set>3)
{
  set=0;flag3=1;
}
delay(100); 

}

  if(set==0)
  {
    //
   // lcd_display();
  }

if(digitalRead (bt_up) == 0)
{
  delay(300);
//if(set==0){tdown.start(); flag2=1;}    // to be uncomment
if(set==1){time_s++;}
if(set==2){time_m++;}
if(set==3){time_h++;}
if(time_s>59){time_s=0;}
if(time_m>59){time_m=0;}
if(time_h>99){time_h=0;}
if(set>0){eeprom_write(); Serial.println(" saving..");

delay(50);

}

}

if(digitalRead (bt_down) == 0)
{
delay(300);
if(set==1){time_s--;}
if(set==2){time_m--;}
if(set==3){time_h--;}
if(time_s<0){time_s=59;}
if(time_m<0){time_m=59;}
if(time_h<0){time_h=99;}
if(set>0){eeprom_write();}
delay(200); 
}

if(digitalRead (bt_start) == 0)
  { 
  delay(50);
  cnt_st++;
  flag2=1;
  if(cnt_st>2)
  {
  cnt_st=0;
  }

 
}

if(set==0 && flag3==1){lcd.setCursor(12,2); lcd.print("SET TIME");}  
if(set==1)
{
  lcd.setCursor(11,0);
lcd.print("        .");
  lcd.setCursor(12,2); lcd.print("set Secs.");
  
  }   //lcd.print("  Set Timer SS  ");
if(set==2)
{    lcd.setCursor(11,0);
lcd.print("        .");
  lcd.setCursor(12,2);lcd.print("set Min.");
  
  }
if(set==3)
{
    lcd.setCursor(11,0);
lcd.print("        .");
  lcd.setCursor(12,2); lcd.print("set Hour");
  
  }

//lcd.setCursor(4,1);

/////////////// delete it not there before


lcd.setCursor(9,3);
if(time_h<=9){lcd.print("0");}
lcd.print(time_h);
lcd.print(":");
if(time_m<=9){lcd.print("0");}
lcd.print(time_m);
lcd.print(":");
if(time_s<=9){lcd.print("0");}
lcd.print(time_s);
lcd.print("   ");

if(time_s==0 && time_m==0 && time_h==0 && flag2==1)
{

flag2=0;
tdown.stop(); 
//tdown.pause(); 
digitalWrite(relay, LOW);
digitalWrite(buzzer, HIGH);
delay(300);
if(set==0)
{lcd.setCursor(11,0);
lcd.print("TIME OFF!");
delay(1700);
}
digitalWrite(buzzer, LOW);
delay(200);
digitalWrite(buzzer, HIGH);
delay(300);
digitalWrite(buzzer, LOW);
delay(200);
digitalWrite(buzzer, HIGH);
delay(300);
digitalWrite(buzzer, LOW);
//lcd.clear();

}

if(flag2==1)
{
if(set==0)
{digitalWrite(relay, HIGH);
tdown.start();
} 
  }

}

void eeprom_write(){
EEPROM.write(1, time_s);  
EEPROM.write(2, time_m);  
EEPROM.write(3, time_h);  
}

void eeprom_read(){
time_s =  EEPROM.read(1);
time_m =  EEPROM.read(2);
time_h =  EEPROM.read(3);
}


void intro()
{
digitalWrite(buzzer, HIGH);
delay (200);
digitalWrite(buzzer, LOW);
lcd.clear();
delay(100);
lcd.setCursor(4, 0);
lcd.print("VeecLAX");
delay(2500);
lcd.setCursor(4, 1);
lcd.print("Adjustable" );
lcd.setCursor(1, 2);
lcd.print("POWER INVERTER");
delay(1000);
lcd.clear();
delay(100);
lcd.setCursor(6, 0);
lcd.print("BY:");
delay(50);
lcd.setCursor(3, 1);
lcd.print("+2348032051780");
lcd.setCursor(0, 2);
lcd.print("Hamladsystems@gmail");
delay(4000);
lcd.clear();
delay(100);
lcd.setCursor(0, 1);
lcd.print("SYSTEM INITIALIZING");
delay(500);
lcd.setCursor(0, 2);
digitalWrite(buzzer, LOW);
for(int i=0; i<16; i++)
{
lcd.setCursor(i, 2);
lcd.print(".");
delay(100);
lcd.setCursor(0, 3);
lcd.print("WAITING"); 
lcd.setCursor(9, 3);
lcd.print(i); 
delay(500);
lcd.setCursor(11, 3);
lcd.print("/"); 
lcd.setCursor(14, 3);
lcd.print(15);
delay(500);
digitalWrite(7, LOW);
}
lcd.clear();
digitalWrite(buzzer, HIGH);
delay(2000);
digitalWrite(buzzer, LOW);
}


int read_adc(int adc_parameter)
{
  
  int sum = 0;
  int sample ;
  for (int i=0; i<AVG_NUM; i++) 
  {                                        // loop through reading raw adc values AVG_NUM number of times  
    sample = analogRead(adc_parameter);    // read the input pin  
    sum += sample;                        // store sum for averaging
    delayMicroseconds(50);              // pauses for 50 microseconds  
  }
  return(sum / AVG_NUM);                // divide sum by AVG_NUM to get average and return it
}


 void read_data(void) 
 {
    //5V = ADC value 1024 => 1 ADC value = (5/1024)Volt= 0.0048828Volt
    // Vout=Vin*R2/(R1+R2) => Vin = Vout*(R1+R2)/R2   R1=100 and R2=20
    
     solar_volt = read_adc(SOL_ADC)*0.00488*(120/20);
    // bat_volt   = read_adc(BAT_ADC)*0.00488*(27/5);
    bat_volt   = read_adc(BAT_ADC)*0.00488*(120/20);
    AC_volt   = read_adc(AC_ADC)*0.00488*(225/5);


   //  
  // 
//  temperature= read_adc(TEMP_ADC)/2;//*100;//(500/1023); /2.046
//  if(temperature>24 && temperature<62 )
//  {
//    temperature-=1;
//  }
//
//  if(temperature>62 && temperature<83)
//  {
//    temperature-=2;  //2
//  }
//
//   if(temperature>83 && temperature<110)
//  {
//    temperature-=3; //3
//  }
//
//   if(temperature>110 && temperature<134)
//  {
//    temperature-=4; //4
//  }
  //-1
  
  //*0.00488*(120/20);
  
  //*(500/1023);
//0.488759
   // 0.48875855

 }

void lcd_display()
{

lcd.setCursor(3,0);
lcd.print(bat_volt,1);
lcd.print("V");
lcd.setCursor(3,1);
lcd.print(solar_volt,1);
lcd.print("V");
lcd.setCursor(3,2);
lcd.print(AC_volt,1);
lcd.print("V");
lcd.setCursor(2,3);
lcd.print(TX,1);
//lcd.print(temperature,1);//TX
lcd.print("C");
  
}


void display_fan2()
{

   lcd.clear();
  lcd.setCursor(0,0);
  lcd.write(1);
  lcd.setCursor(0,1);
  lcd.write(2);
  lcd.setCursor(1,0);
  lcd.write(3);
  lcd.setCursor(1,1);
  lcd.write(4);
  delay (150);
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.write(5);
  lcd.setCursor(0,1);
  lcd.write(6);
  lcd.setCursor(1,0);
  lcd.write(7);
  lcd.setCursor(1,1);
  lcd.write(8);
  delay (150);
}


void display_fan()
{

  // lcd.clear();
  lcd.setCursor(13,0);
  lcd.write(8);
  digitalWrite(FAN_PIN,HIGH);
}

void display_fanoff()
{

  // lcd.clear();
  lcd.setCursor(13,0);
  lcd.print(" ");
  digitalWrite(FAN_PIN,LOW);
}

void static_icon()
{
delay(1000);
lcd.clear();
lcd.setCursor(0,0);
lcd.write(2);
lcd.setCursor(0,1);
lcd.write(6);
lcd.setCursor(0,2);
lcd.write(3);
lcd.setCursor(0,3);
lcd.write(4);
  
}



void read_temp()
{

  VRT = analogRead(TEMP_ADC);              //Acquisition analog value of VRT
  VRT = (5.00 / 1023.00) * VRT;      //Conversion to voltage
  VR = VCC - VRT;
  RT = VRT / (VR / R);               //Resistance of RT

  ln = log(RT / RT0);
  TX = (1 / ((ln / B) + (1 / T0))); //Temperature from thermistor

  TX = TX - 273.15;                 //Conversion to Celsius

//  Serial.print("Temperature:");
//  Serial.print("\t");
//  Serial.print(TX);
//  Serial.print("C\t\t");

//  if(TX>29)
//  {
//
//    display_fan();
//  }
//
//  else
//  {
//display_fanoff();
//    
//  }
//  Serial.print(TX + 273.15);        //Conversion to Kelvin
//  Serial.print("K\t\t");
//  Serial.print((TX * 1.8) + 32);    //Conversion to Fahrenheit
//  Serial.println("F");
  delay(500); 
}


void on_buzzer()
{

  digitalWrite(buzzer,HIGH);
}

void off_buzzer()
{

  digitalWrite(buzzer,LOW);
}



/////////////////////////////////////////////////////////////////////////////////////////////////CHARGER THINGS/////////////////////////////////////////////////////////////////////////////

void system_voltage(void)
{
  if ((bat_volt >BAT_MIN) && (bat_volt < BAT_MAX))
  {
     system_volt = 12;
  }
  /*
  else if  ((bat_volt > BAT_MIN*2 ) && (bat_volt < BAT_MAX*2))
  {
    system_volt=24;
  }*/
  else if ((bat_volt > BAT_MIN/2 ) && (bat_volt < BAT_MAX/2))
  {
    system_volt=6;
  }
  
}
//---------------------------------------------------------------------------------------------------------------------------
 ////////////////////////////////////CHARGE SET POINT ///////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------------------------------------------------------------
 
void setpoint(void)
{
  temp_change =TX-25.0; // 25deg cel is taken as standard room temperature 
 // temperature compensation = -5mv/degC/Cell 
  // If temperature is above the room temp ;Charge set point should reduced
  // If temperature is bellow the room temp ;Charge set point should increased
  if(system_volt ==12)
  {
     bulk_charge_sp = BULK_CH_SP-(0.050*temp_change) ;
     float_charge_sp=FLOAT_CH_SP-(0.050*temp_change) ;
     lvd =LVD;
  }
 
  else if(system_volt ==6)
  {
     bulk_charge_sp = (BULK_CH_SP/2)-(0.015*temp_change) ;
     float_charge_sp= (FLOAT_CH_SP/2)-(0.015*temp_change) ;
     lvd=LVD/2;
  }
  
}
//--------------------------------------------------------------------------------------------------------------------------------
 ///////////////////////////////////////////////////PWM CHARGE CYCLE @500 HZ //////////////////////////////////////////////////
 //-------------------------------------------------------------------------------------------------------------------------------
void charge_cycle(void)

{
  if(solar_volt <= SOL_MIN)
  { 
    read_data();         // Reading voltage temp from the sensors
    setpoint();              // Reading temp compensated charging set point
    PWM_Duty = 0;
    analogWrite(PWM_PIN,PWM_Duty);  //generate PWM from D9 @ 0% duty // Shut down the charger
   // lcd.setCursor(7,0);
   // lcd.print("Charger V low");
  //  Serial.println("CHARGER VOLTAGE LOW");
    }
    
     if((bat_volt < bulk_charge_sp) && (solar_volt> (bat_volt + .5)) && charge_stage == 1)
     
     {
      
    read_data();        // Reading voltage and temp from the sensors
    setpoint();               // Reading temp compensated charging set point
    PWM_Duty = 252.45;
    analogWrite(PWM_PIN,PWM_Duty); // 99 % duty cycle // rapid charging   
   }

if((solar_volt > ( float_charge_sp + .5)))
 
    {
      
    read_data();         // Reading voltage and temp from the sensors
    setpoint();      // Reading temp compensated charging set point
    
    if(bat_volt >= float_charge_sp)
    { // if the battery voltage is more than float charge setpoint then shut down the charger 
      
    PWM_Duty = 0;                    // setting duty cycle =0 to turn off the MOSFET Q1
    analogWrite(PWM_PIN,PWM_Duty);  //generate PWM from D9 @ 0% duty // MOSFET Q1 is OFF
    }
    
    else if(bat_volt <  float_charge_sp - 0.5)
    {
      // if the battery voltage falls below the float charge setpoint then go to stage -1
    charge_stage = 1;
    
    }
   
   }
   
  }  // end of charge cycle
//----------------------------------------------------------------------------------------------------------------------
/////////////////////////////////////////////LOAD CONTROL/////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------  
  

void monitor_action()
{

    if(bat_volt<BAT_MIN ||bat_volt>BAT_MAX )
    {

on_buzzer();
delay(500);
off_buzzer();
//delay(1000);
    }

 else
 {

  off_buzzer();
 }

/////////////////////////////////////////////////////////// TEMPERATURE////////////////////////////////////
  if(TX>29)
  {

    display_fan();
  }

  else
  {
display_fanoff();
    
  }
 

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////END OF CHARGER THINGS//////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////LED INDICATION///////////////////////////////////////////////////////////////////////////////////



void led_indication(void)
{
  solar_led();              //Solar led indication
  battery_led();           //Battery status led indication
  load_led();              //Load led indication
}
//----------------------------------------------------------------------------------------------------------------------
/////////////////////////////////////////////SOLAR LED INDICATION/////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------  
  
  void solar_led()
  
  {
    if (solar_volt < SOL_MIN)
  {  
      digitalWrite(SOL_RED_LED,HIGH);
  } 
  else 
  {
      digitalWrite(SOL_RED_LED,LOW);  //Sun light is not available for charging
      
  }  
     }
//----------------------------------------------------------------------------------------------------------------------
/////////////////////////////////////////////BATTERY LED INDICATION/////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------
void battery_led(void)
{
  
 //  if( (bat_volt > system_volt) && ( bat_volt <bulk_charge_sp))
 if( (bat_volt > BAT_MIN) && ( bat_volt <BAT_MAX+1))
  {   
     // leds_off_all();
      digitalWrite(BAT_RED_LED,LOW); 
      digitalWrite(BAT_GREEN_LED,HIGH);  // battery voltage is healthy
      digitalWrite(LOAD_PIN, HIGH);
      off_buzzer();

  
  } 

   else if(bat_volt < BAT_MIN)
  {
//leds_off_all();
digitalWrite(BAT_GREEN_LED,LOW);
digitalWrite(BAT_RED_LED,HIGH);  // battery voltage low
  digitalWrite(LOAD_PIN, LOW);
on_buzzer();
delay(500);
off_buzzer();
//delay(1000);
  }
}
//----------------------------------------------------------------------------------------------------------------------
/////////////////////////////////////////////LOAD LED INDICATION/////////////////////////////////////////////////////
//----------------------------------------------------------------------------------------------------------------------  
  
  void load_led()

  {
    if(load_status==1)
    {

        //leds_off_all();
//         digitalWrite(BAT_RED_LED,LOW);
//      digitalWrite(BAT_GREEN_LED,HIGH);

    }
    else if(load_status==0)
    {

//        //leds_off_all();
//        digitalWrite(BAT_GREEN_LED,LOW);
//      digitalWrite(BAT_RED_LED,HIGH);

    }
   }



void load_control()
{  

  if(bat_volt >lvd)   // check if battery is healthy 
  {
  load_status=1;
  //digitalWrite(LOAD_PIN, HIGH); // load is ON
  }
  else if(bat_volt < lvd)
  {
    load_status=0;
  // digitalWrite(LOAD_PIN, LOW); //load is OFF
  }

}


void leds_off_all(void)

{ 
  
//  digitalWrite(BAT_RED_LED,LOW);
//  digitalWrite(BAT_GREEN_LED,LOW);

  
  
}


///////////////////////////////////////////////////////////////////////////// END OF LED INDICATION///////////////////////////////////////
