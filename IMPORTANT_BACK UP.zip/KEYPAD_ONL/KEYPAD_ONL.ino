/* This code works with 4x4 Keypad Matrix, LCD ic, IRF510N transistor and a push button
 * It's a lock where the transistor drives a solenoid lock you can open either with correct code
 * or by the push button from inside
 * The code can be changed directly by the keypad and doesn't require uploading code again
 * Code is stored in EEPROM
 * Refer to www.surtrtech.com for more details 
 */

#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>
LiquidCrystal_I2C lcd(0x20,20,4);
#include <Keypad.h>


#define tone_pin  13
#define frequency 50
#define  duration 70


#define Solenoid 11             //Actually the Gate of the transistor that controls the solenoid
#define O_Button 10             //Push Button

       //I2C adress, you should use the code to scan the adress first (0x27) here
#define BACKLIGHT_PIN 3         // Declaring LCD Pins
#define En_pin 2
#define Rw_pin 1
#define Rs_pin 0
#define D4_pin 4
#define D5_pin 5
#define D6_pin 6
#define D7_pin 7

int wrong_count = 0;
 long int time_wrong = 2000;

const byte ROWS = 4; //four rows
const byte COLS = 4; //four columns
//define the cymbols on the buttons of the keypads
char hexaKeys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {2, 3, 4, 5}; //connect to the row pinouts of the keypad
byte colPins[COLS] = {6, 7, 8, 9}; //connect to the column pinouts of the keypad

//initialize an instance of class NewKeypad
Keypad customKeypad = Keypad( makeKeymap(hexaKeys), rowPins, colPins, ROWS, COLS); 
char keypressed;                 //Where the keys are stored it changes very often

char code[4];
//= {'6','6','0','1'};  //The default code, you can change it or make it a 'n' digits one

char code_buff1[sizeof(code)];  //Where the new key is stored
char code_buff2[sizeof(code)];  //Where the new key is stored again so it's compared to the previous one

short a=0,i=0,s=0,j=0;          //Variables used later

void setup()
         {
         Serial.begin(9600);
  pinMode(tone_pin, OUTPUT);
  lcd.init();                      // initialize the lcd 
  // Print a message to the LCD.
  lcd.backlight();
  lcd.setCursor(3,0);
  lcd.print("WELCOME");
 tone(tone_pin, frequency, duration);
customKeypad.addEventListener(keypadEvent); // Add an event listener for this keypad

        //  lcd.print("Standby");      //What's written on the LCD you can change
          pinMode(Solenoid,OUTPUT);
          pinMode(O_Button,INPUT);
         // Serial.print(sizeof(code));
//
//             for(i=0 ; i<sizeof(code);i++){        //When you upload the code the first time keep it commented
//            EEPROM.get(i, code[i]);             //Upload the code and change it to store it in the EEPROM
//             Serial.print(code[i]);
//             }
                      
//          for(i=0 ; i<sizeof(code);i++){        //When you upload the code the first time keep it commented
//            EEPROM.get(i, code[i]);             //Upload the code and change it to store it in the EEPROM
//             }                                  //Then uncomment this for loop and reupload the code (It's done only once)

         }


void loop()
{
get_Ecode();
wrong_sense();
//            for(i=0 ; i<sizeof(code);i++){        //When you upload the code the first time keep it commented
//            EEPROM.get(i, code[i]);             //Upload the code and change it to store it in the EEPROM
//             Serial.print(code);
//             } 
 keypressed = customKeypad.getKey();
  //keypressed = customKeypad.getKey();               //Constantly waiting for a key to be pressed
    if(keypressed == '*'){                      // * to open the lock
            lcd.clear();
            lcd.setCursor(0,0);
            lcd.print("Enter code");            //Message to show
            Serial.print("Enter code");
            GetCode();                          //Getting code function
                  if(a==sizeof(code))           //The GetCode function assign a value to a (it's correct when it has the size of the code array)
                  OpenDoor();                   //Open lock function if code is correct
                  else{
                  lcd.clear();               
                  lcd.print("Wrong");          //Message to print when the code is wrong
                 wrong_count++;
                  }
            delay(2000);
            lcd.clear();
            lcd.print("Standby");             //Return to standby mode it's the message do display when waiting
        }

     if(keypressed == '#'){                  //To change the code it calls the changecode function
      ChangeCode();
      lcd.clear();
      lcd.print("Standby");                 //When done it returns to standby mode
     }

     if(digitalRead(O_Button)==HIGH){      //Opening by the push button
       digitalWrite(Solenoid,HIGH);
       delay(3000);                        //Opens for 3s you can change
       digitalWrite(Solenoid,LOW);
     
     }
         
}

void GetCode(){                  //Getting code sequence
       i=0;                      //All variables set to 0
       a=0;
       j=0; 
                                     
     while(keypressed != 'A'){                                     //The user press A to confirm the code otherwise he can keep typing
           keypressed = customKeypad.getKey();                         
             if(keypressed != NO_KEY && keypressed != 'A' ){       //If the char typed isn't A and neither "nothing"

                              lcd.setCursor(j,1);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
              lcd.print(keypressed);
              delay(50);
              j++;
                delay(100);
              lcd.setCursor(j-1,1);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
                delay(300);
              lcd.print("*");
//              j++;
            if(keypressed == code[i]&& i<sizeof(code)){            //if the char typed is correct a and i increments to verify the next caracter
                 a++;                                              //Now I think maybe I should have use only a or i ... too lazy to test it -_-'
                 i++;

                 
                 
                 }
            else
                a--;                                               //if the character typed is wrong a decrements and cannot equal the size of code []
            
            }
            }
    keypressed = NO_KEY;

}

void ChangeCode(){                      //Change code sequence
      lcd.clear();
      lcd.print("Changing code");
      Serial.println("Changing code");
      delay(800);
      lcd.clear();
      lcd.print("Enter old code");
      Serial.println("Enter old code");
      GetCode();                      //verify the old code first so you can change it
      
            if(a==sizeof(code)){      //again verifying the a value
            lcd.clear();
            lcd.print("Changing code");
            GetNewCode1();            //Get the new code
            GetNewCode2();            //Get the new code again to confirm it
            s=0;
              for(i=0 ; i<sizeof(code) ; i++){     //Compare codes in array 1 and array 2 from two previous functions
              if(code_buff1[i]==code_buff2[i])
              s++;                                //again this how we verifiy, increment s whenever codes are matching
              }
                  if(s==sizeof(code)){            //Correct is always the size of the array
                  
                   for(i=0 ; i<sizeof(code) ; i++){
                  code[i]=code_buff2[i];         //the code array now receives the new code
                  EEPROM.put(i, code[i]);        //And stores it in the EEPROM
                  
                  }
                  lcd.clear();
                  lcd.print("Code Changed");
                  delay(2000);
                  }
                  else{                         //In case the new codes aren't matching
                  lcd.clear();
                  lcd.print("Codes are not");
                  lcd.setCursor(0,1);
                  lcd.print("matching !!");
                  wrong_count++;
                  delay(2000);
                  }
            
          }
          
          else{                     //In case the old code is wrong you can't change it
          lcd.clear();
          lcd.print("Wrong");
          delay(2000);

          wrong_count++;
          }
}

void GetNewCode1(){                      
  i=0;
  j=0;
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Enter new code");   //tell the user to enter the new code and press A
  lcd.setCursor(0,1);
  lcd.print("and press A");
  delay(900);
 // lcd.clear();
  //lcd.setCursor(0,1);
  //lcd.print("and press A");     //Press A keep showing while the top row print ***
             
         while(keypressed != 'A'){            //A to confirm and quits the loop
             keypressed = customKeypad.getKey();
               if(keypressed != NO_KEY && keypressed != 'A' ){
                
              lcd.setCursor(j,2);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
              lcd.print(keypressed);
              delay(50);
              j++;
                delay(100);
              lcd.setCursor(j-1,2);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
                delay(300);
              lcd.print("*");
                
                
//                lcd.setCursor(j,0);
//                lcd.print("*");               //On the new code you can show * as I did or change it to keypressed to show the keys
                code_buff1[i]=keypressed;     //Store caracters in the array
                i++;
                //j++;                    
                }
                }
keypressed = NO_KEY;
}

void GetNewCode2(){                         //This is exactly like the GetNewCode1 function but this time the code is stored in another array
  i=0;
  j=0;
  
  lcd.clear();
   lcd.setCursor(0,0);
  lcd.print("Confirm code");
  lcd.setCursor(0,1);
  lcd.print("and press A");
  delay(3000);
//  lcd.clear();
//  lcd.setCursor(0,1);
//  lcd.print("and press A");

         while(keypressed != 'A'){
             keypressed = customKeypad.getKey();
               if(keypressed != NO_KEY && keypressed != 'A' ){

     lcd.setCursor(j,2);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
              lcd.print(keypressed);

                          //lcd.print(keypressed);
              delay(50);
              j++;
                delay(100);
              lcd.setCursor(j-1,2);                                  //This to write "*" on the LCD whenever a key is pressed it's position is controlled by j
                delay(300);
              lcd.print("*");
                code_buff2[i]=keypressed;
                i++;
               // j++;                    
                }
                }
keypressed = NO_KEY;
}

void OpenDoor(){             //Lock opening function open for 3s
  lcd.clear();
  lcd.print("Welcome");       //With a message printed
  digitalWrite(Solenoid,HIGH);
  delay(3000);
  digitalWrite(Solenoid,LOW);
}



void keypadEvent(KeypadEvent customKey)

{
    switch (customKeypad.getState())
    {
    case PRESSED:
     tone(tone_pin, frequency, duration);
        break;
    case HOLD:

    // 
    tone(tone_pin, frequency, duration);

    }
}


void get_Ecode()
{

    for(i=0 ; i<sizeof(code);i++){        //When you upload the code the first time keep it commented
            EEPROM.get(i, code[i]);             //Upload the code and change it to store it in the EEPROM
            // 
           // Serial.print(code[i]);
             }
}


void wrong_sense()

{

if(wrong_count==3)

{
  for(int i=0;i<wrong_count; i++)
  {

    lcd.clear();
    lcd.setCursor(0,0);
    lcd.print("WRONG INPUT MAX");
     lcd.setCursor(0,1);
    lcd.print("LIMIT EXCEEDED");
lcd.setCursor(0,3);
    lcd.print("WAITING");
    lcd.setCursor(10,3);
lcd.print(i);
lcd.print("/");
lcd.print(wrong_count);
delay(time_wrong);
    
    
  }
  wrong_count=0;
}

  
}
