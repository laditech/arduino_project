//
//    FILE: I2Ckeypad_demo01.ino
//  AUTHOR: Rob Tillaart
// PURPOSE: demo
//     URL: https://github.com/RobTillaart/I2CKeyPad
//
//  PCF8574
//    pin p0-p3 rows
//    pin p4-p7 columns
//  4x4 or smaller keypad.


#include "Wire.h"
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// LCD:     DB7       -> Arduino Digital 6
//          DB6       -> Arduino Digital 7
//          DB5       -> Arduino Digital 8
//          DB4       -> Arduino Digital 9
//          E         -> Arduino Digital 10
//          RS        -> Arduino Digital 11
#include <EEPROM.h>
#include <SoftwareSerial.h>
#include <LiquidCrystal.h>
#include <DS1302.h>      // rtc(clock)
const int rs = 11, en = 10, d4 = 9, d5 = 8, d6 = 7, d7 = 6;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
DS1302 rtc(2, 3, 4);
uint32_t start, stop;
//uint32_t lastKeyPressed = 0;
Time  t = rtc.getTime();

#include "functions.h"

//////////////////////////////////////////////////pressing things///////////////////////////////////
   
void setup()
{
 Serial.begin(9600);
 lcd.begin(20, 4);
  //intro();
  delay(50);
  pinMode(PLUS, INPUT);
  pinMode(MINUS, INPUT);
  pinMode(ENTER, INPUT);
  pinMode(TIMESW, INPUT);
  pinMode(RELAY, OUTPUT);
  digitalWrite(RELAY, LOW);
  Serial.println(__FILE__);

  //rtc.setDOW(THURSDAY);        // Set Day-of-Week to FRIDAY
  //rtc.setTime(21, 33, 6);     // Set the time to 12:00:00 (24hr format)
 // rtc.setDate(5, 2, 2021); // Set the date to February 5th, 2021 

}

void loop()

{ 
startall:
  t = rtc.getTime();
  read_time();  // recall all set time from EEPROM
  reset_counter();  // if all three key press reset current key value


if(digitalRead(TIMESW)==HIGH)
{
  timeswitch =1;  // use to controll timer mode on/ off
}

else
{

 timeswitch =0;
}


if(timeswitch==1)
{ 
///////////////////////////////////////////////////////////////////////////////////////////////////////////// PUT ALL FUNCTIONS HERE//////////////////////////////////////
  if (t.hour == hourst && t.min == minst)
   {
    //LIGHT ON 
    Serial.println("LIGH ON");
    //Serial.println(rtc.getDateStr());
    delay(3);
    digitalWrite(RELAY,HIGH);
   }
  if (t.hour == hoursp && t.min == minsp)
   {
    //LIGHT OFF 
    delay(5);
    digitalWrite(RELAY,LOW);
   }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////END OF ALL FUNCTION HER///////

}

else
{

//digitalWrite(RELAY,LOW);
  
}
if(resettimer==1)
{
  
  restpara();
  delay(30);
  goto startall;

  
}

if(digitalRead(PLUS)==HIGH && digitalRead(MINUS)==HIGH)
{
delay(170);
statustime=1;  
}

time_status();

if(digitalRead(ENTER)==HIGH)
{

  delay(500);
  entpress = 1;
  entcount++;
  Serial.println("ENTER PRESSS");
  Serial.println(entcount);
  
plus_press();
minus_press();

} // end of Enter==HIGH
////////////////////////////////// start something////////////////////////////////////

if(entpress==1)
{
delay(5);
if(entcount==5)
{
  
  hourmode=1;
  lcd.clear();
  lcd.setCursor(0,0);
  delay(1);
  entcount=0;

}

//////////////////////////////////////////////////////////////////////////////////////HOUR MODE////
hour_mode();

//////////////////////////////////////////////START MINUTE  MODE BEGIN//////
min_mode();

////////stop HOUR BEGIN/////
hstop_mode();

/////////////////////////////////////////////////////STOP MINUTE START////
minstop_mode();

//entpress=0;

}// end of start press-first h mode

}// end of loop


// -- END OF FILE --
