//byte OnHour   = 1;  //  for the DEMONSTRATION consider,
//byte OnMin    = 49;   //      12:00:05 - MORNING(light ON))
//byte OnSec    = 7;    //    & 12:00:15 - NIGHT  (light OFF) 
//byte OffHour  = 12;
//byte OffMin   = 0;
//byte OffSec   = 15; 
byte resettimer=0;
int hourst;
int hoursp;
int minst;
int minsp; 
//String dateing   = "16.03.2022"; 
////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 #define PLUS    A3 //3
 #define MINUS   A2 //4
 #define ENTER   A1 //5
 #define TIMESW   13  //2
 #define RELAY   12  


#define CH_HST    0    //50
#define CH_MIST   2 //message 2


#define CH_HSP    6    //50
#define CH_MISP   8 //message 2

int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM////////////////////////////////////////////////////////////////////////////////////////////////////////
int entpress;
int pluspress;
int minuspress;

int entmode;
byte hourmode;
byte minmode;
byte hourmodestop;
byte minmodestop;


int entcount = 0;
int pluscount = 0;
int minuscount = 0;

int staday;
int stahour;
int stamin;

int stopday;
int stophour;
int stopmin;

byte hourcount;
byte mincount;
byte statustime=0;
byte usin = 1;
byte timeswitch =0;



 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }
//     EEPROM.commit(); 
  }

void read_time()
{
    
if(usin==1)
 {
  
hourst = EEPROM.read(CH_HST);
delay(500);
minst = EEPROM.read(CH_MIST);
delay(500);
hoursp = EEPROM.read(CH_HSP);
delay(500);
minsp = EEPROM.read(CH_MISP);
delay(500);

//Serial.print("Time-HOUR::");
//Serial.println(t.hour);
//Serial.print("Time-MIN::");
//Serial.println(t.min);

Serial.println("START HOUR:");
Serial.println(hourst);

Serial.println("STOP HOUR:");
Serial.println(hoursp);

Serial.println("START MINUTE:");
Serial.println(minst);

Serial.println("STOP MINUTE:");
Serial.println(minsp);
delay(100);
usin = 0;
 
}
}

void reset_counter()
{

  
if(digitalRead(PLUS)==HIGH && digitalRead(MINUS)==HIGH && digitalRead(ENTER)==HIGH)
{ 
resettimer=1;
Serial.println("RESET COUNTER");
stahour=0;
stamin=0;
stophour=0;
stopmin=0;

}



}




void restpara()
{

hourmode=0;
usin=1;
hourmodestop=0;
minmode=0;
minmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
resettimer=0;
delay(200);
//goto startall;
  
}




void time_status()
{

    if(statustime==1)
  {
lcd.clear();
delay(500);
lcd.setCursor(0,0);
lcd.print("CURRENT SET TIME::");
lcd.setCursor(0,1);
lcd.print("START H:");

lcd.setCursor(1,2); 
//
lcd.print(hourst); //hourst 

lcd.setCursor(8,1);
lcd.print("M");

lcd.setCursor(3,2); 
lcd.print(" : "); 
lcd.print(minst); 
lcd.setCursor(11,1);
lcd.print("STOP H:");

lcd.setCursor(9,2);
lcd.print(">"); 

lcd.setCursor(10,2);
lcd.print(hoursp); 

lcd.setCursor(18,1);
lcd.print("M");

lcd.setCursor(12,2);
lcd.print(" "); 
lcd.print(" : "); 
lcd.print(minsp);
delay(500);

delay(2000);
lcd.clear();
statustime=0;    

}
}

void plus_press()
{

if(digitalRead(PLUS)==HIGH && digitalRead(MINUS)==LOW)
{
  delay(300);
  pluspress = 1;
  pluscount++;
  Serial.println("PLUS PRESSS");
  Serial.println(pluscount);
 
 }  

}// end of plus_press


void minus_press()
{
if(digitalRead(MINUS)==HIGH && digitalRead(PLUS)==LOW)
{
  delay(300);
  minuspress = 1;
  if(pluscount>0)
  {
  pluscount--;
  }
  Serial.println("MINUS PRESSS");
  Serial.println(pluscount);
  
}
} // minus press end


void hour_mode()
{

if(hourmode==1)
{

delay(70);
hourmodestop=0;
minmodestop=0;
minmode=0;
delay(3);
lcd.setCursor(0,0);
lcd.print("ENTER START HOUR"); 
lcd.setCursor(10,1);

if(digitalRead(PLUS)==HIGH)
{
  if(hourcount<23)
  
{
hourcount++;
delay(500);
stahour = hourcount;
delay(11);
lcd.setCursor(5,1);
lcd.print(stahour);
delay(30); 

}

}

 if(digitalRead(MINUS)==HIGH)
{
  delay(900);
if(hourcount>0)
 
{
  hourcount--;
delay(70);
  stahour = hourcount;
  delay(3);
  lcd.setCursor(5,1);
 lcd.print(stahour);
}
 
}

////////////////////////////////////////////////////////END OF START HOUR MODE////////////////////////////////////////////////////////////////

lcd.setCursor(0,3);
 lcd.print("LONG PRESS ENTER TO CONTINUE"); 
 
if(entcount==3)
{
    // save start hour here
lcd.clear();
delay(70);
hourmode=0;
hourmodestop=0;
minmodestop=0;
minmode=1;
hourcount = 0;
mincount=0;
entcount=0;

}

}  // end of hourmode

} // end of hour mode function

void min_mode()
{


if(minmode==1)
{

delay(5);
lcd.setCursor(0,0);
lcd.print("ENTER START MINUTE");
lcd.setCursor(10,1);
if(digitalRead(PLUS)==HIGH)
{
  
if(mincount<=59)
  
{   
++mincount;
delay(300);
stamin = mincount;
lcd.setCursor(5,1);
lcd.print(stamin);
}

}

if(digitalRead(MINUS)==HIGH)
{
  
  delay(700);
 if(mincount>0)
  {
  mincount--;
  delay(900);
  stamin = mincount;
  lcd.setCursor(5,1);
 lcd.print(stamin);
  }
 
}

lcd.setCursor(0,3);
lcd.print("LONG PRESS ENTER TO CONTINUE"); 
////////////////////////////////////////////////////// END OF Start MINUTE MODE, HOUR STOP BEGIN/////////////////////// 
if(entcount==3)
 {
// save start minute here
  lcd.clear();
  delay(70);
  hourmode=0;
  hourmodestop=1;
minmode=0;
minmodestop=0;
hourcount = 0;
entcount=0;
}
 
}

}// min_mode





hstop_mode()
{

if(hourmodestop==1)
{
  
delay(5);
lcd.setCursor(0,0);
mincount = 0;
delay(3);
lcd.print("ENTER STOP HOUR"); 
lcd.setCursor(10,1);
 
 if(digitalRead(PLUS)==HIGH)
{
  if(hourcount<23)
 {
hourcount++;
delay(500);
stophour = hourcount;
delay(11);
lcd.setCursor(5,1);
lcd.print(stophour);
delay(30);
}

}
if(digitalRead(MINUS)==HIGH)
 
 {
  delay(900);

if(hourcount>0)
  {
  hourcount--;
delay(900);
  stophour = hourcount;
  delay(3);
  lcd.setCursor(5,1);
 lcd.print(stophour);

}
}



////////////////////////////////////////////////////////END OF HOUR MODE////////////////////////////////////////////////////////////////
lcd.setCursor(0,3);
 //entcount = 0;
 lcd.print("LONG PRESS ENTER TO CONTINUE"); 

if(entcount==3)
{
    // save start hour here
  lcd.clear();
  delay(70);
  hourmode=0;
  hourmodestop=0;
minmode=0;
minmodestop=1;
hourcount = 0;
entcount=0;
}

////////////////////////// end of stop hour///////////////
 
}

  
} // end of hstop_mode function



void minstop_mode()
{

if(minmodestop==1)
{
  delay(5);
//lcd.clear();
lcd.setCursor(0,0);
lcd.print("ENTER STOP MINUTE");
lcd.setCursor(10,1);
 
 if(digitalRead(PLUS)==HIGH)
{
  if(mincount<=60)
  {
mincount++;
delay(700);
stopmin = mincount;
lcd.setCursor(5,1);
 lcd.print(stopmin);
}
}

 if(digitalRead(MINUS)==HIGH)
{
  lcd.setCursor(5,1);
  delay(700);
    if(mincount>0)
  {
  mincount--;
delay(900);
  stopmin = mincount;
 // lcd.setCursor(5,1);
 lcd.print(stopmin);

}
  
}
lcd.setCursor(0,3);
lcd.print("PRESS ENTER TO CONTINUE"); 

////////////////////////////////////////////////////// END OF Start MINUTE MODE///////////////////////  

 if(entcount==3)
{
  E_clear(0, EEPROM.length());
  delay(500);
  if((stophour>=stahour) && (stopmin!=stamin))
  {
delay(500);
    Serial.println("ready to save..");
   // 
   lcd.clear();
    delay(500);
  //lcd.print("THIS IS A SAVE");

 // EEPROM.write(addr, val);
EEPROM.put(CH_HST,stahour); delay(300);
 if(EEPROM.put(CH_HST,stahour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR");
   Serial.println(stahour);
 }
 

EEPROM.put(CH_MIST,stamin); delay(300);
  if(EEPROM.put(CH_MIST,stamin))
 {
   delay(50);
  Serial.println("SUCESS SAVE MIN-START");
  Serial.println(stamin);
 }
 
EEPROM.put(CH_HSP,stophour);delay(300);

 if(EEPROM.put(CH_HSP,stophour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR-STOP");
  Serial.println(stophour);
 }

 
EEPROM.put(CH_MISP,stopmin);
delay(300);
 if(EEPROM.put(CH_MISP,stopmin))
 {
   delay(5);
  Serial.println("SUCESS SAVE MIN-STOP");
  Serial.println(stopmin);
 }
delay(50);
lcd.setCursor(2,0);
lcd.print("ON"); 
lcd.setCursor(12,0);
lcd.print("OFF"); 

lcd.setCursor(0,1);
lcd.print(""); 
lcd.print(stahour); 
lcd.print(" "); 
lcd.print(" : "); 
lcd.print(stamin); 
lcd.print(" "); 
lcd.print(">>"); 
lcd.print(" "); 
lcd.print(stophour); 
lcd.print(" : "); 
lcd.print(stopmin);
lcd.print(" "); 
delay(500);
//lcd.clear();

for(int i=0; i<20;i++)
{
  lcd.setCursor(0,2);
  lcd.print("SAVING");
  lcd.setCursor(i,3);
  lcd.print(".");
  delay(100);
}
delay(30);
hourmode=1;
usin=1;
hourmodestop=0;
minmode=0;
minmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
delay(100);
//goto startall;

}

else
{

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Start time");
  lcd.setCursor(0,1);
  lcd.print("must be less than");
   lcd.setCursor(0,2);
  lcd.print("Stop time");

delay(10);
hourmode=1;
usin=1;
hourmodestop=0;
minmode=0;
minmodestop=0;
//hourcount = 0;
entcount=0;
//statustime=0;
delay(2500);
lcd.clear();
delay(10);
//goto startall;
}
  
} 
}

  
} // end of minstop_mode





void intro()
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("TIME BASED APPLIANCE");
delay(100);
lcd.setCursor(4,2);
//lcd.print("APPLIANCE");
delay(100);
//lcd.setCursor(0,2);
lcd.print("CONTROLLER");
delay(1500);
lcd.clear();
lcd.setCursor(1,2);
lcd.print("PRESS * ");
delay(100);
//lcd.setCursor(0,1);
lcd.print("FOR OPTIONS");
lcd.clear();
lcd.setCursor(0,0);
lcd.print("Select CH number");
delay(100);
//
lcd.setCursor(0,1);
lcd.print("To view schedule");

lcd.setCursor(7,2);
lcd.print("or press");
delay(100);
//
lcd.setCursor(7,3);
lcd.print("* for OPTIONS");
delay(1000);
  
}
