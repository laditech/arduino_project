byte resettimer=0;
int hourst;
int hoursp;
//String dateing   = "16.03.2022"; 
#define PLUS    P4
#define MINUS   P3 //4
#define ENTER   P5 //5
#define TIMESW   P6  //2
#define RELAY    P0  
#define CRMRELAY   P7  
#define FAN   P1 
#define BUZ   P2
#define CH_HST    0    //50
#define CH_HSP    6    //50
//int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM////////////////////////////////////////////////////////////////////////////////////////////////////////
int entpress;
int pluspress;
int minuspress;

int entmode;
byte hourmode;
byte hourmodestop;

int entcount = 0;
int pluscount = 0;
int minuscount = 0;

int stahour;
int stophour;
byte hourcount;
byte statustime=0;
byte usin = 1;
byte timeswitch =0;

 
 void(* resetFunc) (void) = 0;
 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }

  }

void read_time()
{
    
if(usin==1)
 {
  
hourst = EEPROM.read(CH_HST);
delay(500);
delay(500);
hoursp = EEPROM.read(CH_HSP);
delay(500);
delay(500);
Serial.println("START HOUR:");
Serial.println(hourst);
Serial.println("STOP HOUR:");
Serial.println(hoursp);
delay(100);
usin = 0;
}
}

void reset_counter()
{ 
if(pcf8574.digitalRead(PLUS)==HIGH && pcf8574.digitalRead(MINUS)==HIGH && pcf8574.digitalRead(ENTER)==HIGH)
{ 
resettimer=1;
Serial.println("RESET COUNTER");
stahour=0;
stophour=0;
}
}

void restpara()
{
  
hourmode=0;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
resettimer=0;
delay(200);
//goto startall;  
}

void time_status()
{

if(pcf8574.digitalRead(PLUS)==HIGH && pcf8574.digitalRead(MINUS)==HIGH)
{
delay(5);
entpress = 0;
hourmode=0;
entcount=0;
statustime=1;  
}


  
if(statustime==1)
  {
lcd.clear();
delay(500);
lcd.setCursor(0,0);
lcd.print("CURRENT SET TIME::");
lcd.setCursor(0,2);
lcd.print("START H:");
lcd.setCursor(5,3); 
//
lcd.print(hourst); //hourst 

lcd.setCursor(10,2);
lcd.print("STOP H:");
lcd.setCursor(11,3); 
lcd.print(hoursp); 
delay(500);
delay(2000);
lcd.clear();
statustime=0;    
}
}

void plus_press()
{

if(pcf8574.digitalRead(PLUS)==HIGH && pcf8574.digitalRead(MINUS)==LOW)
{
  delay(300);
  pluspress = 1;
  pluscount++;
  Serial.println("PLUS PRESSS");
  Serial.println(pluscount);
 
 }  

}// end of plus_press


void minus_press()
{
if(pcf8574.digitalRead(MINUS)==HIGH && pcf8574.digitalRead(PLUS)==LOW)
{
  delay(300);
  minuspress = 1;
  if(pluscount>0)
  {
  pluscount--;
  }
  Serial.println("MINUS PRESSS");
  Serial.println(pluscount);
  
}
} // minus press end


void hour_mode()
{

if(hourmode==1)
{

delay(70);
hourmodestop=0;
delay(3);
lcd.setCursor(0,0);
lcd.print("ENTER START HOUR"); 
//
lcd.setCursor(10,1);
if(pcf8574.digitalRead(PLUS)==HIGH)
{
  //
  lcd.setCursor(5,1);
  if(hourcount<23)  
{
hourcount++;
delay(500);
stahour = hourcount;
delay(3);
//
lcd.setCursor(5,1);
//
lcd.print(stahour);
//lcd.print(hourcount);
//delay(30); 
}

}

 if(pcf8574.digitalRead(MINUS)==HIGH)
{

if(hourcount>0)
 
{
  hourcount--;
delay(500);
  stahour = hourcount;
   delayMicroseconds(1);
  lcd.clear();
 // 
 delayMicroseconds(50);
  lcd.setCursor(5,1);
 lcd.print(stahour);
 //lcd.print(hourcount);
}

}
////////////////////////////////////////////////////////END OF START HOUR MODE////////////////////////////////////////////////////////////////

lcd.setCursor(0,3);
lcd.print("& PRES ENT X3"); 
 
if(entcount==4)
{
    // save start hour here
lcd.clear();
delay(70);
hourmode=0;
hourmodestop=1;
//minmode=1;
hourcount = 0;
entcount=0;

}

}  // end of hourmode

} // end of hour mode function

void hstop_mode()
{

if(hourmodestop==1)
{
  delay(5);
//lcd.clear();
lcd.setCursor(0,0);
lcd.print("ENTER STOP HOUR");
lcd.setCursor(10,1);
 
 if(pcf8574.digitalRead(PLUS)==HIGH)
{
  if(hourcount<23)
  {
hourcount++;
delay(700);
stophour = hourcount;
lcd.setCursor(5,1);
lcd.print(stophour);
}
}

 if(pcf8574.digitalRead(MINUS)==HIGH)
{
  lcd.setCursor(5,1);
  delay(500);
    if(hourcount>0)
  {
  hourcount--;
delay(500);
  stophour = hourcount;
   delayMicroseconds(1);
  lcd.clear();
 // 
 delayMicroseconds(50);
  lcd.setCursor(5,1);
 lcd.print(stophour);
 //lcd.print(hourcount)
}
  
}
lcd.setCursor(0,3);
lcd.print("PRESS ENTER X3"); 

////////////////////////////////////////////////////// END OF Start MINUTE MODE///////////////////////  

 if(entcount==4)
{
 E_clear(0, EEPROM.length());
 delay(100);
 if((stophour>=stahour) && (stophour!=0&&stahour!=0))
  {
delay(100);
    Serial.println("ready to save..");
   lcd.clear();
    delay(50);
EEPROM.put(CH_HST,stahour); delay(300);
 if(EEPROM.put(CH_HST,stahour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR");
   Serial.println(stahour);
 }

EEPROM.put(CH_HSP,stophour);delay(300);

 if(EEPROM.put(CH_HSP,stophour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR-STOP");
  Serial.println(stophour);
 }

delay(50);
lcd.setCursor(3,0);
lcd.print("ON"); 
lcd.print(""); 
lcd.print(" "); 
lcd.print(">>");
lcd.setCursor(3,1);
lcd.print(""); 
lcd.print(stahour); 
lcd.setCursor(10,0);
lcd.print("OFF"); 
lcd.setCursor(7,1);
lcd.print(" "); 
lcd.print(stophour); 
delay(700);
//lcd.clear();

for(int i=0; i<=20;i++)
{
  lcd.setCursor(0,2);
  lcd.print("SAVING");
  lcd.setCursor(i,3);
  lcd.print(".");
  delay(100);
}
delay(30);
hourmode=1;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
delay(100);
resetFunc();
//goto startall;

}

else
{

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Stop time");
  lcd.setCursor(0,1);
  lcd.print("must be greater than");
   lcd.setCursor(0,2);
  lcd.print("Start time");

delay(10);
hourmode=1;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
delay(2500);
lcd.clear();
delay(10);
//goto startall;
}
} 
}

} // end of minstop_mode


void enter_hour_mode()
{

if(pcf8574.digitalRead(ENTER)==HIGH)
{
  delay(607);
  entpress = 1;
  entcount++;
plus_press();
minus_press();

} // end of Enter==HIGH
////////////////////////////////// start something////////////////////////////////////

if(entpress==1)
{
delay(5);
if(entcount==7)
{ 
  hourmode=1;
  lcd.clear();
  //lcd.setCursor(0,0);
  delay(1);
  entcount=0;

}
hour_mode();
hstop_mode();

}
  
}

void timer_sw()

{
if(pcf8574.digitalRead(TIMESW)==HIGH)
{
  delay(3);
  timeswitch =1;  // use to controll timer mode on/ off
//Serial.println("HIGH SW");
}

else //(pcf8574.digitalRead(TIMESW)==LOW)
{
  delay(5);
 timeswitch =0;
// Serial.println("LOW");
}

  
}
