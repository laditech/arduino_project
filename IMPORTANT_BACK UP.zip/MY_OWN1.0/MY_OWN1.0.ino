  
#include <avr/io.h>
#include <avr/interrupt.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 20, 4);  // set the LCD address to 0x27 for a 16 chars and 2 line display
#include <Wire.h>
#include "RTClib.h"
RTC_DS1307 rtc;
#include "Arduino.h"
#include "PCF8574.h"
PCF8574 pcf8574(0x20);
#include <EEPROM.h>


const byte vfbPin = A0,
           tfbPin = A1,
           battPin = A2;
volatile double percentMod;
int phs;
int             pininv= 5;      //EDIT THE PIN
int             ext= 4;


//sine wave (Look Up Table) 
int lookUp1[] = {
  0, 25, 50, 75, 100, 125, 150, 175, 199, 223, 247, 271, 294, 318, 341, 363, 385, 407, 429, 450,
  470, 490, 510, 529, 548, 566, 583, 600, 616, 632, 647, 662, 675, 689, 701, 713, 724, 734, 744, 753,
  761, 768, 775, 781, 786, 790, 794, 796, 798, 800, 800, 800, 798, 796, 794, 790, 786, 781, 775, 768,
  761, 753, 744, 734, 724, 713, 701, 689, 675, 662, 647, 632, 616, 600, 583, 566, 548, 529, 510, 490,
  470, 450, 429, 407, 385, 363, 341, 318, 294, 271, 247, 223, 199, 175, 150, 125, 100, 75, 50, 25, 0
};



#include "functions.h"


byte solar[8] = //icon for solar panel
{
  
 B01010,
  B01010,
  B11111,
  B10001,
  B10001,
  B10001,
  B01110,
  B00100
  //0b11111,0b10101,0b11111,0b10101,0b11111,0b10101,0b11111,0b00000
};
byte battery[8] =  //icon for battery
{
  0b01110,0b11011,0b10001,0b10001,0b10001,0b10001,0b10001,0b11111
};

byte timerChar[8] = {
  B01110,
  B10001,
  B10101,
  B10101,
  B10001,
  B01010,
  B00100,
  B00000
};


byte energy[8] =  // icon for power
{
  0b00010,0b00100,0b01000,0b11111,0b00010,0b00100,0b01000,0b00000
};
/*byte alarm[8] =  // icon for alarm
{
 0b00000,0b00100,0b01110,0b01110,0b01110,0b11111,0b00000,0b00100
};*/
byte temp[8] = //icon for termometer
{
 0b00100,0b01010,0b01010,0b01110,0b01110,0b11111,0b11111,0b01110
};

byte charge[8] = // icon for battery charge
{
  0b01010,0b11111,0b10001,0b10001,0b10001,0b01110,0b00100,0b00100,
};
byte not_charge[8]=
{
  0b00000,0b10001,0b01010,0b00100,0b01010,0b10001,0b00000,0b00000,
};



void setup() {

  Serial.begin(9600);
  TCCR1A = 0b10110000;
  TCCR1B = 0b00010001;
  TIMSK1 = 0b00000001;
  ICR1 = 800;       
  sei();             /* Enable global interrupts.*/
  DDRB = 0b00011110; /* Pin 9, 10, 11, 12 as outputs.*/
  PORTB = 0;


   pcf8574.pinMode(RELAY, OUTPUT);
 pcf8574.pinMode(FAN, OUTPUT);
 pcf8574.pinMode(BUZ, OUTPUT);
 pcf8574.pinMode(PLUS, INPUT);
 pcf8574.pinMode(MINUS, INPUT);
 pcf8574.pinMode(ENTER, INPUT);
 pcf8574.pinMode(TIMESW, INPUT);
 pcf8574.begin();
  pinMode(13, OUTPUT); //led
  pinMode(8, OUTPUT);  //fanctl
  pinMode(7, OUTPUT);  //buzzer
  pinMode(2, INPUT_PULLUP);
  pinMode(5, INPUT);  //buzzer


  
// if (! rtc.begin()) {
//    Serial.println("Couldn't find RTC");
//    Serial.flush();
//    while (1) delay(10);
//  }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 Serial.println(__FILE__);
pcf8574.digitalWrite(RELAY,LOW); 

  percentMod = 0.01;
//  for (int i = 0; i < 75; i++) {  // Soft Start
//    percentMod = percentMod + 0.01;
//    delay(20);
//  }



  
  lcd.init();
//lcd.createChar(1,solar);
lcd.createChar(2, battery);
lcd.createChar(1, temp);
//
lcd.createChar(3, energy);
//lcd.createChar(4,alarm);
lcd.createChar(5, timerChar);
lcd.createChar(6,charge);
lcd.createChar(7,not_charge);
lcd.clear();
lcd.setCursor(0, 0);
//lcd.print("Batt--Vout--Temp");

//lcd.print("VOUT:");
lcd.write(3);

lcd.setCursor(0, 1);

//lcd.print("BAT:");
lcd.write(2);
lcd.print(":");

lcd.setCursor(0, 2);

lcd.write(1);
lcd.print(":");
//lcd.print("TEMP: ");

lcd.setCursor(0, 3);

lcd.print("MODE: ");

lcd.setCursor(9, 2);

lcd.print("TIMER:");
//lcd_display();

rtc.adjust(DateTime(2014, 1, 21, 4, 15, 0));
}





void loop() {

  startall:
  DateTime now = rtc.now();
 read_data();
 action_it();
 



//  if (phs == 1) {
//    vfbValue1 = vfbValue;
//    vMax=max(vMax,vfbValue);
//
//    vfbValue = analogRead(vfbPin);  // vfbPin = 0 to 5V ---> vfbValue = 0 to 1023
//
//   // if (vfbValue > vfbValue1 && vfbValue > 200) vfbRise = 1;  //check for POSITIVE cycle
//    if (vfbValue > 200) vfbRise = 1;  //check for POSITIVE cycle
//
//    if (vfbValue < vfbValue1 && vfbRise == 1) {               // maximum vfb value reached
//      vfbRise = 0;
//      Serial.println("thissss");
//      ampDiff = 614 - vfbValue1;
//      if (ampDiff > 5 || ampDiff < -5) {
//        percentMod = percentMod + (ampDiff / vfbValue1);  
//        if (percentMod > 0.97) percentMod = 0.97;    
//      }
//      feedBackTest(vfbValue1, analogRead(tfbPin), analogRead(battPin));    
//    }
//    
//    if (vMax<=50 && phs==0) alrmCnt++;     
//    if (alrmCnt>=1) alarmIndication(20);   
//  } else  vMax=0;




}// loop


//TIMER OVER FLOW
ISR(TIMER1_OVF_vect) {
  static int num;
  static int ph;
  static int dtA = 0;
  static int dtB = 5;

  if (num >= 99) {          
                            
    if (ph == 0) {          // OC1A as SPWM out
      TCCR1A = 0b10110000;  // clear OC1A, set OC1B on compare match
      dtA = 0;              
      dtB = 5;              
    } else {
      TCCR1A = 0b11100000;  // OC1B as SPWM out
      dtA = 5;
      dtB = 0;
    }
    ph ^= 1;
  }
  OCR1A = int(lookUp1[num] * percentMod) + dtA;  // 
  OCR1B = int(lookUp1[num] * percentMod) + dtB;  // note: 0.7 used to reduce inveter output voltage

  num++;
  if (num >= 100) {  // toggle left bridge (50Hz) !!!
    delayMicroseconds(60);
    if (ph == 1) {
      digitalWrite(12, LOW);
      digitalWrite(11, HIGH);
      phs = 1;
    } else {
      digitalWrite(11, LOW);
      digitalWrite(12, HIGH);
      phs = 0;
    }
    num = 0;
  }
}





/*void intro()
{
   digitalWrite(3, HIGH);  // turn ON LED and Buzzer
   delay (200);
   lcd.clear();
   delay(200);
   lcd.setCursor(4, 0);
   lcd.print("\"EVERY HOME\"");
   delay(200);
   digitalWrite(3, LOW);
   delay(200); 
   lcd.setCursor(4, 1);
   lcd.print("Adjustable" );
       
   lcd.setCursor(1, 2);
    lcd.print("POWER INVERTER");
   delay(500);
   lcd.clear();
   lcd.setCursor(6, 0);
   lcd.print("BY:");
   delay(400);
   lcd.setCursor(3, 1);
   lcd.print("08032051780");
   lcd.setCursor(0, 2);
   lcd.print("Hamladsystems@gmail");
   delay(4000);
   lcd.clear();
   delay(700);
   lcd.setCursor(0, 1);
   lcd.print("SYSTEM INITIALIZING");
   delay(500);
   digitalWrite(3, HIGH);
   for(int i=0; i<16; i++)
{
   lcd.setCursor(i, 1);

   lcd.print(".");
   delay(300);
    lcd.setCursor(1, 3);
   lcd.print("WAITING"); 
   lcd.print(i); 
    delay(500);
   lcd.setCursor(8, 3);
   lcd.print("/"); 
   lcd.setCursor(9, 3);
   lcd.print(15);
   delay(500);
   digitalWrite(3, LOW);
}
}
*/
void stndBy(int status){
    if (status==1) {DDRB = 0; digitalWrite(5,HIGH); }            // when pin 5 is high my spwm pins will shut down
    if (status==2) {DDRB = 0b00111100; digitalWrite(5,LOW);}     // the opposite of the above 
    //if (status==0 && digitalRead(9)==LOW){                       // 
    digitalWrite(5,LOW);
    } 


    
void alarmIndication(int alarm) {
  TCCR1A = 0;  // shutdown SPWM output
  TIMSK1 = 0;
  PORTB &= 0b11100001;

  lcd.clear();
  lcd.setCursor(4, 0);
  lcd.print("WARNING!");
  lcd.setCursor(0, 1);
  if (alarm == 2) lcd.print(" UNDER VOLTAGE");
  if (alarm == 3) lcd.print("  OVER VOLTAGE");
  if (alarm == 4) lcd.print("OVER TEMPERATURE");
  if (alarm == 5) lcd.print("  LOW BATTERY");
  if (alarm == 20) lcd.print(" SHORT CIRCUIT");

loopX:
  for (int i = 0; i < alarm; i++) {
    digitalWrite(7, HIGH);  // turn ON LED and Buzzer
    digitalWrite(13, HIGH);
    delay(200);
    digitalWrite(7, LOW);  // then turn OFF
    digitalWrite(13, LOW);
    delay(200);
  }
  delay(1000);
  goto loopX;  
}

void feedBackTest(float vfbIn, int tfbIn, int battIn) {
  long alrm;
  static int alrmCnt;
  static int dispCnt;
  float dis1;
  float dis2;
  float dis3;

  if (digitalRead(2) == LOW) return;
  if (phs != 1) return;

  alrm = constrain(vfbIn, 462, 660);
  if (alrm != vfbIn) alrmCnt++;
  else
    alrmCnt = 0;
    Serial.print(alrm);
  if (alrm == 462 && alrmCnt >= 150) alarmIndication(2); Serial.println("undervolatge");             // underVoltage at 2.5V --> 2.75 / 5 x 1023 = 562
  if (alrm == 660 && alrmCnt >= 15) alarmIndication(3);              // overVoltage at 3.15V --> 3.15 / 5 x 1023 = 645
  if (tfbIn >= 924) alarmIndication(4);                              // over temp at 80C --> 10k/(10k + 1.068k) x 1023 =924
  if (battIn <= 457) alarmIndication(5);                             // low batt at 10.5V --> (2k7/12.7k x 10.5) / 5 x 1023 = 457
  if (tfbIn >= 725 && digitalRead(8) == LOW) digitalWrite(8, HIGH);  // fan ON at 45C --> 725
  if (tfbIn <= 679 && digitalRead(8) == HIGH) digitalWrite(8, LOW);  // fan OFF at 40C --> 679

  if (dispCnt >= 2) {   //50     // display updated 
    dis1 = battIn * 0.02299;  // constant is the result of reversing the above calculation
    dis2 = vfbIn * 0.3560;
    dis3 = abs((tfbIn - 512) / 11.0) +25;
   
    lcd.setCursor(0, 0);
    lcd.print("Vout:" + String(dis2, 0));
    lcd.setCursor(10, 0);
    if (digitalRead(ext==HIGH)) lcd.print("BatM:EX");  else lcd.print("BatM:IN");
    lcd.setCursor(0, 2);
    lcd.print("Temp:" + String(dis3, 1));
    lcd.setCursor(0, 3);
    lcd.print("Batt:" + String(dis1, 1) + "MODE:");
    if (digitalRead(5)==LOW)  lcd.print("INV"); else lcd.print("GD");    
    dispCnt = 0;
  }
  dispCnt++;
}


void mode(int pininv)
{
      lcd.setCursor(0,3);
      lcd.print("BAT-MODE:");
      if(digitalRead(pininv==HIGH))
  {
      lcd.setCursor(6,3);
      lcd.print("mains");
  }
     else if(digitalRead(pininv==LOW))
  {
      lcd.setCursor(6,2);
      lcd.print("IVT");  
  }
}
      
