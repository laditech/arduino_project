//byte OnHour   = 1;  //  for the DEMONSTRATION consider,
//byte OnMin    = 49;   //      12:00:05 - MORNING(light ON))
//byte OnSec    = 7;    //    & 12:00:15 - NIGHT  (light OFF) 
//byte OffHour  = 12;
//byte OffMin   = 0;
//byte OffSec   = 15; 


#define AVG_NUM 5
#define BAT_ADC A2
#define VF_ADC A0
#define TEMP_ADC A1 
#define HVF  24
#define LVF  20
#define LVD  10.5
#define HVD  16
float bat_volt=0;
float vf_volt=0;
int tempc=0;
byte resettimer=0;
int hourst;
int hoursp;
//String dateing   = "16.03.2022"; 
#define PLUS    P4
#define MINUS   P3 //4
#define ENTER   P5 //5
#define TIMESW   P6  //2
#define RELAY   P0  
#define FAN   P1 
#define BUZ   P2
#define CH_HST    0    //50
#define CH_HSP    6    //50
//int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM////////////////////////////////////////////////////////////////////////////////////////////////////////
int entpress;
int pluspress;
int minuspress;

int entmode;
byte hourmode;
byte hourmodestop;

int entcount = 0;
int pluscount = 0;
int minuscount = 0;

int stahour;
int stophour;
byte hourcount;
byte statustime=0;
byte usin = 1;
byte timeswitch =0;
 void(* resetFunc) (void) = 0;
 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }

  }

void read_time()
{
    
if(usin==1)
 {
  
hourst = EEPROM.read(CH_HST);
delay(500);
delay(500);
hoursp = EEPROM.read(CH_HSP);
delay(500);
delay(500);
Serial.println("START HOUR:");
Serial.println(hourst);
Serial.println("STOP HOUR:");
Serial.println(hoursp);
delay(100);
usin = 0;
}
}

void reset_counter()
{ 
if(pcf8574.digitalRead(PLUS)==HIGH && pcf8574.digitalRead(MINUS)==HIGH && pcf8574.digitalRead(ENTER)==HIGH)
{ 
resettimer=1;
Serial.println("RESET COUNTER");
stahour=0;
stophour=0;
}
}

void restpara()
{
  
hourmode=0;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
resettimer=0;
delay(200);
//goto startall;  
}

void time_status()
{
if(statustime==1)
  {
lcd.clear();
delay(500);
lcd.setCursor(0,0);
lcd.print("CURRENT SET TIME::");
lcd.setCursor(0,2);
lcd.print("START H:");
lcd.setCursor(5,3); 
//
lcd.print(hourst); //hourst 

lcd.setCursor(10,2);
lcd.print("STOP H:");
lcd.setCursor(11,3); 
lcd.print(hoursp); 
delay(500);
delay(2000);
lcd.clear();
statustime=0;    
}
}

void plus_press()
{

if(pcf8574.digitalRead(PLUS)==HIGH && pcf8574.digitalRead(MINUS)==LOW)
{
  delay(300);
  pluspress = 1;
  pluscount++;
  Serial.println("PLUS PRESSS");
  Serial.println(pluscount);
 
 }  

}// end of plus_press


void minus_press()
{
if(pcf8574.digitalRead(MINUS)==HIGH && pcf8574.digitalRead(PLUS)==LOW)
{
  delay(300);
  minuspress = 1;
  if(pluscount>0)
  {
  pluscount--;
  }
  Serial.println("MINUS PRESSS");
  Serial.println(pluscount);
  
}
} // minus press end


void hour_mode()
{

if(hourmode==1)
{

delay(70);
hourmodestop=0;
delay(3);
lcd.setCursor(0,0);
lcd.print("ENTER START HOUR"); 
//
lcd.setCursor(10,1);
if(pcf8574.digitalRead(PLUS)==HIGH)
{
  //
  lcd.setCursor(5,1);
  if(hourcount<23)  
{
hourcount++;
delay(500);
stahour = hourcount;
delay(3);
//
lcd.setCursor(5,1);
//
lcd.print(stahour);
//lcd.print(hourcount);
//delay(30); 
}

}

 if(pcf8574.digitalRead(MINUS)==HIGH)
{

if(hourcount>0)
 
{
  hourcount--;
delay(500);
  stahour = hourcount;
  lcd.clear();
 // 
 delayMicroseconds(0.5);
  lcd.setCursor(5,1);
 lcd.print(stahour);
 //lcd.print(hourcount);
}

}
////////////////////////////////////////////////////////END OF START HOUR MODE////////////////////////////////////////////////////////////////

lcd.setCursor(0,3);
lcd.print("& PRES ENT X3"); 
 
if(entcount==4)
{
    // save start hour here
lcd.clear();
delay(70);
hourmode=0;
hourmodestop=1;
//minmode=1;
hourcount = 0;
entcount=0;

}

}  // end of hourmode

} // end of hour mode function

void hstop_mode()
{

if(hourmodestop==1)
{
  delay(5);
//lcd.clear();
lcd.setCursor(0,0);
lcd.print("ENTER STOP HOUR");
lcd.setCursor(10,1);
 
 if(pcf8574.digitalRead(PLUS)==HIGH)
{
  if(hourcount<23)
  {
hourcount++;
delay(700);
stophour = hourcount;
lcd.setCursor(5,1);
lcd.print(stophour);
}
}

 if(pcf8574.digitalRead(MINUS)==HIGH)
{
  lcd.setCursor(5,1);
  delay(700);
    if(hourcount>0)
  {
  hourcount--;
delay(900);
  stophour = hourcount;
 // lcd.setCursor(5,1);
 lcd.print(stophour);
lcd.clear();
delay(1);
}
  
}
lcd.setCursor(0,3);
lcd.print("PRESS ENTER X3"); 

////////////////////////////////////////////////////// END OF Start MINUTE MODE///////////////////////  

 if(entcount==4)
{
 E_clear(0, EEPROM.length());
 delay(100);
 if((stophour>=stahour) && (stophour!=0&&stahour!=0))
  {
delay(100);
    Serial.println("ready to save..");
   lcd.clear();
    delay(50);
EEPROM.put(CH_HST,stahour); delay(300);
 if(EEPROM.put(CH_HST,stahour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR");
   Serial.println(stahour);
 }

EEPROM.put(CH_HSP,stophour);delay(300);

 if(EEPROM.put(CH_HSP,stophour))
 {
  delay(50);
  Serial.println("SUCESS SAVE HOUR-STOP");
  Serial.println(stophour);
 }

delay(50);
lcd.setCursor(3,0);
lcd.print("ON"); 
lcd.print(""); 
lcd.print(" "); 
lcd.print(">>");
lcd.setCursor(3,1);
lcd.print(""); 
lcd.print(stahour); 
lcd.setCursor(10,0);
lcd.print("OFF"); 
lcd.setCursor(7,1);
lcd.print(" "); 
lcd.print(stophour); 
delay(700);
//lcd.clear();

for(int i=0; i<=20;i++)
{
  lcd.setCursor(0,2);
  lcd.print("SAVING");
  lcd.setCursor(i,3);
  lcd.print(".");
  delay(100);
}
delay(30);
hourmode=1;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
lcd.clear();
delay(100);
resetFunc();
//goto startall;

}

else
{

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Stop time");
  lcd.setCursor(0,1);
  lcd.print("must be greater than");
   lcd.setCursor(0,2);
  lcd.print("Start time");

delay(10);
hourmode=1;
usin=1;
hourmodestop=0;
hourcount = 0;
entcount=0;
//statustime=0;
delay(2500);
lcd.clear();
delay(10);
//goto startall;
}
} 
}

} // end of minstop_mode
  void off_spwm_Mosf()

{

  TCCR1A = 0;  // shutdown SPWM output
  TIMSK1 = 0;
  PORTB &= 0b11100001;

}

int read_adc(int adc_parameter)
{
  
  int sum = 0;
  int sample ;
  for (int i=0; i<AVG_NUM; i++) 
  {                                        // loop through reading raw adc values AVG_NUM number of times  
    sample = analogRead(adc_parameter);    // read the input pin  
    sum += sample;                        // store sum for averaging
    delayMicroseconds(50);              // pauses for 50 microseconds  
  }
  return(sum / AVG_NUM);                // divide sum by AVG_NUM to get average and return it
}


 void read_data(void) 
 {
    //5V = ADC value 1024 => 1 ADC value = (5/1024)Volt= 0.0048828Volt
    // Vout=Vin*R2/(R1+R2) => Vin = Vout*(R1+R2)/R2   R1=100 and R2=20
    
    // solar_volt = read_adc(SOL_ADC)*0.00488*(120/20);
    
     bat_volt   = read_adc(BAT_ADC)*0.00488*(120/20);
     vf_volt   = read_adc(VF_ADC)*0.00488*(120/20);
     tempc   = (read_adc(TEMP_ADC)*500)/1023;  


lcd.setCursor(3, 0);
lcd.print(vf_volt);
lcd.print("V");

lcd.setCursor(3, 1);
lcd.print(bat_volt);
lcd.print("V");

lcd.setCursor(3, 2);
lcd.print(tempc);
 lcd.print("C");

  }

void action_it()
{
if(bat_volt>=HVD)
{
  pcf8574.digitalWrite(RELAY,HIGH); 
//lcd.clear();
//lcd.setCursor(0,0);
//lcd.print("");
  // fully charged
}

  else
  {
pcf8574.digitalWrite(RELAY,LOW);  // CHARGING
if(bat_volt<=LVD)
{
off_spwm_Mosf();
  //lcd.clear();
lcd.setCursor(0,0);
lcd.print("WARNIGN!!");
lcd.setCursor(0,1);
lcd.print("BATTERY LOW");
lcd.setCursor(0,2);
lcd.print("SHUT DOWN MODE");
}
    
  }
if(vf_volt>=HVF)
{

pcf8574.digitalWrite(BUZ,HIGH); 
//lcd.clear();
lcd.setCursor(0,0);
lcd.print("OVER VOLTAGE");
lcd.setCursor(0,1);
lcd.print(" @ ");
lcd.print(vf_volt);
}


if(vf_volt<=LVF)
{
//lcd.clear();
pcf8574.digitalWrite(BUZ,HIGH); 
delay(500);
pcf8574.digitalWrite(BUZ,HIGH); 
lcd.setCursor(0,0);
lcd.print("UNDER VOLTAGE");
lcd.setCursor(0,1);
lcd.print(" @ ");
lcd.print(vf_volt);
}



  
}

void lcd_display()
{
 // Display Solar Panel Parameters
// lcd.setCursor(0, 0);
// lcd.write(1);
// lcd.setCursor(2, 0);
// lcd.print(solar_volt,1);
// lcd.print("V");
// 
// lcd.setCursor(8, 0);
// lcd.print(solar_current,1);
// lcd.print("A");
// lcd.setCursor(14,0);
// lcd.print(solar_watts,1);
// lcd.print("W");


 // Display Battery Parameters
 lcd.setCursor(0,0);
 lcd.write(2);
 lcd.setCursor(2, 1);
 lcd.print(bat_volt,1);
 lcd.print("V");
 lcd.setCursor(8, 1);
 lcd.write(5);
 lcd.setCursor(9, 1);
 lcd.print(tempc);
 //lcd.write(1);
 lcd.print("C");
// lcd.write(0b11011111);
// lcd.print("C");
// lcd.setCursor(14, 1);
// lcd.write(2);
// if((charge_stage==1) | (charge_stage== 2) | (charge_stage== 3))
// {
// lcd.write(6);
// }
// else
// {
// lcd.write(7);
// }

 // Display Load Parameters
//
// lcd.setCursor(0,2);
// lcd.print("L");
// lcd.setCursor(2,2);
// lcd.print(load_current,1);
// lcd.print("A");
// lcd.setCursor(8,2);
// lcd.print(load_watts,1); 
// lcd.print("W");
// lcd.setCursor(14,2);
// if(load_status==1)
//    {
//      lcd.print("   "); 
//      lcd.setCursor(14,2);
//      lcd.print("ON"); 
//    }
//    else if(load_status==0)
//    {
//      lcd.print("OFF"); 
//    }

 // Display Energy 
// lcd.setCursor(0,3);
// lcd.write(3);
// lcd.setCursor(2,3);
//lcd.print(solar_wattHours,1);
// lcd.print("Wh");  
// lcd.setCursor(8,3);
// lcd.print(load_wattHours,1);
// lcd.print("Wh");
  
}
