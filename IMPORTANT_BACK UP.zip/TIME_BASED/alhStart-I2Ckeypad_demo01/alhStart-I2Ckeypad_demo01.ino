//
//    FILE: I2Ckeypad_demo01.ino
//  AUTHOR: Rob Tillaart
// PURPOSE: demo
//     URL: https://github.com/RobTillaart/I2CKeyPad
//
//  PCF8574
//    pin p0-p3 rows
//    pin p4-p7 columns
//  4x4 or smaller keypad.


#include "Wire.h"
#include "I2CKeyPad.h"
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// LCD:     DB7       -> Arduino Digital 6
//          DB6       -> Arduino Digital 7
//          DB5       -> Arduino Digital 8
//          DB4       -> Arduino Digital 9
//          E         -> Arduino Digital 10
//          RS        -> Arduino Digital 11
#include <EEPROM.h>
#include <SoftwareSerial.h>
#include <LiquidCrystal.h>
#include <DS1302.h>      // rtc(clock)
#include "functions.h"
const int rs = 11, en = 10, d4 = 9, d5 = 8, d6 = 7, d7 = 6;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
DS1302 rtc(2, 3, 4);

const uint8_t KEYPAD_ADDRESS = 0x20; //38
I2CKeyPad keyPad(KEYPAD_ADDRESS);

uint32_t start, stop;
uint32_t lastKeyPressed = 0;
Time  t = rtc.getTime();

byte OnHour   = 1;  //  for the DEMONSTRATION consider,
byte OnMin    = 49;   //      12:00:05 - MORNING(light ON))
byte OnSec    = 7;    //    & 12:00:15 - NIGHT  (light OFF) 
byte OffHour  = 12;
byte OffMin   = 0;
byte OffSec   = 15;  
String dateing   = "16.03.2022"; 
////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
String rehst="";
String remst="";
String resst="";
String rehsp="";
String remsp="";
String ressp="";

String reyst="";
String remost="";
String redst="";
String reysp="";
String remosp="";
String redsp="";




  
#define CH_Y    0     //10
#define CH_M    5     //10
#define CH_D    7     //10
#define CH_H    11    //50
#define CH_MI    14 //message 2
#define CH_S   17  //138

//#define CH_PS2    25


char dd[]="12";
char dm[]="10";
char dy[]="2022";
String alldate="";

//
char h[]="1";  
char m[]="30";  
char s[]="25"; 

char h2[]="15";  
char m2[]="47";  
char s2[]="58"; 
char d2[]="30.07.2025";
//"no 11, adura shopping complex, oro ,kwara state complex,";

int success;

//////////////////////////////////////////////////////////////////////////// VARIABLES - LENGTH///////////////////////////////////////////////////
//
//int l_d = 19;
//int l_h = 2;
//int l_m = 2;
//int l_s = 2; //57;

int l_dy;
int l_dd;
int l_dm;
int l_h;
int l_m;
int l_s; //57;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EEPROM////////////////////////////////////////////////////////////////////////////////////////////////////////
int chpress;
int harshpress;
byte starpress;
int chn;
String chs="";
int chind;
//////////////////////////////////////////////////pressing things///////////////////////////////////
int Relay = A5;
int sbutton = 10;
int pbutton = 11;
int mbutton = 12;
int selectb = A6;
int minusb = A7;
int plusb = 12;
 uint8_t index;
 uint8_t indexset;
 
    String join="";
    String joinset="";
    int  trackpress=0;
    int intjoin;
    int intjoinset;
    String strhour="";
    String strmin="";
    String strsec="";
    int inthour;
    int intmin;
    int intsec;
    
void setup()
{

  Serial.begin(9600);

 lcd.begin(20, 4);
  //
  intro();
  delay(50);
  Serial.println(__FILE__);
  Wire.begin();
  Wire.setClock(400000);
  if (keyPad.begin() == false)
  {
    Serial.println("\nERROR: cannot communicate to keypad.\nPlease reboot.\n");
    while(1);
  }
}


void loop()
{
  String comp="135";
  uint32_t now = millis();
  char keys[] = "123A456B789C*0#D";  // N = NoKey, F = Fail

  if (now - lastKeyPressed >= 100)
  {
    start:
    lastKeyPressed = now;
    start = micros();
    if(keyPad.isPressed())
    {
      
     index = keyPad.getKey();
     delay(1);
    join+=String(keys[index]);
   
     delay(1);
Serial.println("JOIN:"+join);

      if(join.length()>0 && join.length()<2)
      {

        chpress=1;
        intjoin = join.toInt();
        delay(30);
      Serial.println(intjoin);


                     if(join=="*")
                     {
                      
                      delay(50);
                      starpress=1;
              trackpress=0;
              Serial.println("* press");
              
                   //option(starpress); 
              
                     
                  }


             if(join=="#")
             
             
             {
                          starpress=0;
              trackpress=0;
                  delay(10);
                  harshpress++;
                 Serial.println("# press");
          //harshpress=1;
            
             }



//
join="";

      } // end of >0<2

      
/****************************************************************          EDIT CHANEL                                               ***********************************************/     
        
        
        
//if(starpress==1 /*&& chpress==1 && harshpress<3*/ )
// 
// {
// // 
// //joinset="";
//  //
//  trackpress=1;
//  chpress=0;
//  Serial.println("ENTER CHANEL NUMBER TO EDIT");
//  lcd.clear();
//  delay(750);
//  lcd.setCursor(0,0);
//  lcd.print("ENTER CHANEL NUMBER TO EDIT");
////
//lcd.setCursor(0,0);
//  lcd.print(intjoin);
//
//
//
// }
//        
//if(trackpress==1)   // && joinset.length()>0 && joinset.length()<3 
//{
//
//
// lcd.clear();
// joinset+=String(keys[index]);
//  delay(50);
//
////
////settings(trackpress);
////setting_ch(intjoin, trackpress);
//  
//
//  delay(2);
// 
//if(joinset!="#" && joinset!="A"&& joinset!="B" && joinset!="C" && joinset!="D")
//
//{
//
//}
//
//}



if(intjoin>0)
{


}



/****************************************************************EDIT CHANEL ***********************************************/     


    }// end of key press

    stop = micros();
   
    delay(100);

  } // END OF PRESS KEYPAD




///////////////////////////////////////////////////////////////////////////////////////////////END OF KEY PRESS///////////////////////////////////////////////////////////////////////////  

//
//             if(join=="#")
//             
//             
//             {
//                  
//                  delay(10);
//                  harshpress++;
//                 Serial.println("# press");
//          //harshpress=1;
//          
//                 Serial.println(harshpress);
          
                               if(harshpress>2)
                               
                               {
                                starpress=0;
                                chpress=0;
                                joinset="";
                                intjoinset=0;
                                intro2(); delay(500); harshpress=0;
                                
                                }   
                                 
                 
                 
                 //}  // END OF # PRESS




      if(trackpress==0 && starpress==0 && intjoin>0 && chpress==1)
      {
      //selected_ch(intjoin);
      view_ch(intjoin);
      //chpress=1;

      }



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

if(starpress==1 /*&& chpress==1 && harshpress<3*/ )
 
 {
 // 
 //joinset="";
  //
 // trackpress=1;
  chpress=0;
  Serial.println("ENTER CHANEL NUMBER TO EDIT");
  //
  lcd.clear();
  delay(1000);
  lcd.setCursor(0,0);
  lcd.print("ENTER CHANEL NUMBER TO EDIT");
//
lcd.setCursor(0,3);
  lcd.print(intjoin);
if(intjoin>0)
{
  trackpress=1;
  
 
}


 }
        
if(trackpress==1 && harshpress==0)   // && joinset.length()>0 && joinset.length()<3 
{

//
starpress=0; 
 //lcd.clear();
 //lcd.print(intjoin);
// index=0;
 //joinset="";
 indexset= keyPad.getKey();
 delay(3);
 joinset+=String(keys[indexset]);
delay(100);

//join="";
setting_ch(intjoin, trackpress,joinset);
//settings(trackpress);
//join="";
  delay(2);
 
if(joinset!="#" && joinset!="A"&& joinset!="B" && joinset!="C" && joinset!="D")

{

}

}

///////////////////////////////////////////////////////////////////////////////////////////////END OF KEY PRESS///////////////////////////////////////////////////////////////////////////  


  
} // END OF LOOP
//////////////////////////////////////////////////////////////////***************************************** FUNCTIONS*************************************************************************************///////////////

void intro()
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("TIME BASED APPLIANCE");
delay(100);
lcd.setCursor(4,2);
//lcd.print("APPLIANCE");
delay(100);
//lcd.setCursor(0,2);
lcd.print("CONTROLLER");
delay(1500);
lcd.clear();
lcd.setCursor(1,2);
lcd.print("PRESS * ");
delay(100);
//lcd.setCursor(0,1);
lcd.print("FOR OPTIONS");
lcd.clear();
lcd.setCursor(0,0);
lcd.print("Select CH number");
delay(100);
//
lcd.setCursor(0,1);
lcd.print("To view schedule");

lcd.setCursor(7,2);
lcd.print("or press");
delay(100);
//
lcd.setCursor(7,3);
lcd.print("* for OPTIONS");
delay(1000);
  
}




void intro2()
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("Select CH number");
delay(100);
//
lcd.setCursor(0,1);
lcd.print("TO VIEW SCHEDULE");

lcd.setCursor(0,2);
lcd.print("OR PRESS * FOR OPTIONS");
delay(100);
//
delay(1000);
  
}



void view_ch(int ch)
{

  //READ EEPROM
  if(ch>0)
  {


if(ch==1)
{

dateingy1  = read_it(CH_Y1,4+CH_Y1); 
dateingy1sp  = read_it(CH_Y1SP,4+CH_Y1SP);
dateingm1  = read_it(CH_M1,2+CH_M1); 
dateingm1sp  = read_it(CH_M1SP,2+CH_M1SP); 
dateingd1  = read_it(CH_D1,2+CH_D1); 
dateingd1sp  = read_it(CH_D1SP,2+CH_D1SP); 
houring1  = read_it(CH_H1,2+CH_H1); 
houring1sp  = read_it(CH_H1SP,2+CH_H1SP); 
mining1  = read_it(CH_MI1,2+CH_MI1);
mining1sp  = read_it(CH_MI1SP,2+CH_MI1SP);
secing1  = read_it(CH_S1,2+CH_S1); 
secing1sp  = read_it(CH_S1SP,2+CH_S1SP); 



} // end of ch1

else if(ch==2)
{

dateingy1  = read_it(CH_Y2,4+CH_Y2); 
dateingy1sp  = read_it(CH_Y2SP,4+CH_Y2SP);
dateingm1  = read_it(CH_M2,2+CH_M2); 
dateingm1sp  = read_it(CH_M2SP,2+CH_M2SP); 
dateingd1  = read_it(CH_D2,2+CH_D2); 
dateingd1sp  = read_it(CH_D2SP,2+CH_D2SP); 
houring1  = read_it(CH_H2,2+CH_H2); 
houring1sp  = read_it(CH_H2SP,2+CH_H2SP); 
mining1  = read_it(CH_MI2,2+CH_MI2);
mining1sp  = read_it(CH_MI2SP,2+CH_MI2SP);
secing1  = read_it(CH_S2,2+CH_S2); 
secing1sp  = read_it(CH_S2SP,2+CH_S2SP); 

}


else if(ch==3)
{

dateingy1  = read_it(CH_Y3,4+CH_Y3); 
dateingy1sp  = read_it(CH_Y3SP,4+CH_Y3SP);
dateingm1  = read_it(CH_M3,2+CH_M3); 
dateingm1sp  = read_it(CH_M3SP,2+CH_M3SP); 
dateingd1  = read_it(CH_D3,2+CH_D3); 
dateingd1sp  = read_it(CH_D3SP,2+CH_D3SP); 
houring1  = read_it(CH_H3,2+CH_H3); 
houring1sp  = read_it(CH_H3SP,2+CH_H3SP); 
mining1  = read_it(CH_MI3,2+CH_MI3);
mining1sp  = read_it(CH_MI3SP,2+CH_MI3SP);
secing1  = read_it(CH_S3,2+CH_S3); 
secing1sp  = read_it(CH_S3SP,2+CH_S3SP); 

}


else if(ch==4)
{

dateingy1  = read_it(CH_Y4,4+CH_Y4); 
dateingy1sp  = read_it(CH_Y4SP,4+CH_Y4SP);
dateingm1  = read_it(CH_M4,2+CH_M4); 
dateingm1sp  = read_it(CH_M4SP,2+CH_M4SP); 
dateingd1  = read_it(CH_D4,2+CH_D4); 
dateingd1sp  = read_it(CH_D4SP,2+CH_D4SP); 
houring1  = read_it(CH_H4,2+CH_H4); 
houring1sp  = read_it(CH_H4SP,2+CH_H4SP); 
mining1  = read_it(CH_MI4,2+CH_MI4);
mining1sp  = read_it(CH_MI4SP,2+CH_MI4SP);
secing1  = read_it(CH_S4,2+CH_S4); 
secing1sp  = read_it(CH_S4SP,2+CH_S4SP); 

}

else
{


dateingy1  = ""; 
dateingy1sp  = "";
dateingm1  =""; 
dateingm1sp  = ""; 
dateingd1  = ""; 
dateingd1sp  = ""; 
houring1  = ""; 
houring1sp  = ""; 
mining1  ="";
mining1sp  = "";
secing1  = ""; 
secing1sp  = ""; 
  
}





    
 // 

lcd.setCursor(0,0);
lcd.print("YOU ARE IN CHANEL:");
lcd.print(ch);
lcd.setCursor(0,1);
lcd.print("START:");
lcd.setCursor(0,2);
//lcd.print("13");
lcd.print(houring1);
lcd.print(":");
lcd.print(mining1);
//lcd.print("05");
lcd.print(":");
lcd.print(secing1);
//lcd.print("57");

lcd.setCursor(0,3);
lcd.print(dateingm1);
//lcd.print("14");
lcd.print(".");
lcd.print(dateingd1);
//lcd.print("01");
lcd.print(".");
lcd.print(dateingy1);
//lcd.print(dateingy1);


lcd.setCursor(11,1);
lcd.print("STOP:");
lcd.setCursor(11,2);

lcd.print(houring1sp);
lcd.print(":");
lcd.print(mining1sp);
//lcd.print("05");
lcd.print(":");
lcd.print(secing1sp);
//


lcd.setCursor(10,3);

lcd.print(dateingm1sp);
//lcd.print("14");
lcd.print(".");
lcd.print(dateingd1sp);
//lcd.print("01");
lcd.print(".");
lcd.print(dateingy1sp);

 delay(1500);
 lcd.clear();
  }
  
}

void settings(int check)
{
if(check==1)
{

  lcd.clear();
lcd.setCursor(0,1);
lcd.print("ENTER HOUR:-");
 
}
  
}
void selected_ch(int ch)
{



  


  
}

void option(int clicki)
{

if(clicki==1&& harshpress>0)
{
  
  //READ EEPROM

  lcd.clear();
  delay(750);
lcd.setCursor(0,0);
lcd.print("ENTER CHANNEL NUMBER:");
lcd.setCursor(0,1);
lcd.setCursor(0,2);

lcd.print("OR LONG PRESS # EXIT");
delay(1000);
clicki=0; 

}

}


void save_id(char id[],int sta, int clen)
{
int t= 0;
for(int i = sta; i < clen+1; i++)
  {
    // 
  //  Serial.println(i);
    
        EEPROM.put(i, id[t++]);
     
//       success = 1; 

 
     
    }


  
}

void setting_ch(int ch, int cond,String injoinset)
{

if(cond==1 && harshpress==0)

{
  
  lcd.clear();
  lcd.setCursor(0,0);
  Serial.println("you are in channel");
  Serial.print(ch);
 lcd.print("CHANNEL:");
 lcd.setCursor(11,0);
//  if(injoinset.length()<1)
// {
 lcd.print(ch);
 //join="";
// }

lcd.setCursor(0,1);
lcd.print(" ENTER START"); 
lcd.setCursor(0,2);
lcd.print("HOUR =  "); 
lcd.setCursor(0,3);
 //lcd.print(injoinset); 



 while(injoinset.length()<3)

 {
   lcd.print(injoinset); 
  
 }
}

 
}



 void E_clear(int sta, int sto)
  {


for (int i = sta ; i < sto ; i++) 
{
    EEPROM.write(i, 0);
  }
//     EEPROM.commit(); 
  }




String read_it(int sta, int clen)
{
   char inprom1;
  String inRprom1 = "";
for(int i = sta; i < clen; i++){
  
    
 
   inprom1 = EEPROM.read(i);
   
   inRprom1.concat(inprom1);
}

if(inRprom1.length()>0)
{
return inRprom1;

}

}

// -- END OF FILE --
