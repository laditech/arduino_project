#define CH_Y1    0     //10        // START CH1
#define CH_M1    5     //10
#define CH_D1    8     //10  7
#define CH_H1    11    //50
#define CH_MI1    14 //message 2
#define CH_S1   17  //138

#define CH_Y1SP    20     //10
#define CH_M1SP    25     //10
#define CH_D1SP    28     //10        //STOP CH1
#define CH_H1SP    31    //50
#define CH_MI1SP   34 //message 2
#define CH_S1SP    37 //138

#define CH_Y2    40     //10 36
#define CH_M2    45     //10        // START CH2
#define CH_D2    48     //10
#define CH_H2    51    //50
#define CH_MI2   54 //message 2    // MISTAKE CORRECT
#define CH_S2    57 //138

#define CH_Y2SP    60     //10
#define CH_M2SP    65     //10
#define CH_D2SP    68     //10
#define CH_H2SP    71    //50
#define CH_MI2SP   74 //message 2
#define CH_S2SP    77 //138

#define CH_Y3    80     //10 
#define CH_M3    85     //10
#define CH_D3    88     //10
#define CH_H3    91    //50
#define CH_MI3   94 //message 2
#define CH_S3    97  //138

#define CH_Y3SP    100     //10
#define CH_M3SP    105     //10
#define CH_D3SP    108     //10
#define CH_H3SP    111    //50
#define CH_MI3SP   114 //message 2
#define CH_S3SP    117 //138

#define CH_Y4    120     //10
#define CH_M4    125     //10
#define CH_D4    128     //10
#define CH_H4    131    //50
#define CH_MI4   134 //message 2
#define CH_S4    137  //138

#define CH_Y4SP    140     //10
#define CH_M4SP    145     //10
#define CH_D4SP    148     //10
#define CH_H4SP    151    //50
#define CH_MI4SP   154 //message 2
#define CH_S4SP    157  //138
String stat = "";
String dateingy1 = "";
String dateingy2 = "";
String dateingy3 = "";
String dateingy4 = "";

String dateingy1sp = "";
String dateingy2sp = "";
String dateingy3sp = "";
String dateingy4sp = "";

String dateingm1 = "";
String dateingm2 = "";
String dateingm3 = "";
String dateingm4 = "";


String dateingm1sp = "";
String dateingm2sp = "";
String dateingm3sp = "";
String dateingm4sp = "";




String dateingd1 = "";
String dateingd2 = "";
String dateingd3 = "";
String dateingd4 = "";

String dateingd1sp = "";
String dateingd2sp = "";
String dateingd3sp = "";
String dateingd4sp = "";



String houring1 = "";
String houring2 = "";
String houring3 = "";
String houring4 = "";

String houring1sp = "";
String houring2sp = "";
String houring3sp = "";
String houring4sp = "";


String mining1 = "";
String mining2 = "";
String mining3 = "";
String mining4 = "";

String mining1sp = "";
String mining2sp = "";
String mining3sp = "";
String mining4sp = "";

String secing1 = "";
String secing2 = "";
String secing3 = "";
String secing4 = "";

String secing1sp = "";
String secing2sp = "";
String secing3sp = "";
String secing4sp = "";

int l_dy1;
int l_dd1;
int l_dm1;
int l_h1;
int l_m1;
int l_s1; //57;

int l_dy2;
int l_dd2;
int l_dm2;
int l_h2;
int l_m2;
int l_s2; //57;

int l_dy3;
int l_dd3;
int l_dm3;
int l_h3;
int l_m3;
int l_s3; //57;


int l_dy4;
int l_dd4;
int l_dm4;
int l_h4;
int l_m4;
int l_s4; //57;


int l_dy1sp;
int l_dd1sp;
int l_dm1sp;
int l_h1sp;
int l_m1sp;
int l_s1sp; //57;

int l_dy2sp;
int l_dd2sp;
int l_dm2sp;
int l_h2sp;
int l_m2sp;
int l_s2sp; //57;

int l_dy3sp;
int l_dd3sp;
int l_dm3sp;
int l_h3sp;
int l_m3sp;
int l_s3sp; //57;

int l_dy4sp;
int l_dd4sp;
int l_dm4sp;
int l_h4sp;
int l_m4sp;
int l_s4sp; //57;
/*
 * 
 * 
 * 
 *   if (isDigit(thisChar)) {
      Serial.println("it's a numeric digit");
    }
      if (isPunct(thisChar)) {
      Serial.println("it's punctuation");
    }

       if (isAlpha(thisChar)) {
      Serial.println("it's alphabetic");
    }

    
 */
//
//void save_id(char id[],int sta, int clen)
//{
//int t= 0;
//for(int i = sta; i < clen+1; i++)
//  {
//    // 
//  //  Serial.println(i);
//    
//        EEPROM.put(i, id[t++]);
//     
////       success = 1; 
//
// 
//     
//    }
//
//
//  
//}
//
//
// void E_clear(int sta, int sto)
//  {
//
//
//for (int i = sta ; i < sto ; i++) 
//{
//    EEPROM.write(i, 0);
//  }
////     EEPROM.commit(); 
//  }
//
//
//
//
//String read_it(int sta, int clen)
//{
//   char inprom1;
//  String inRprom1 = "";
//for(int i = sta; i < clen; i++){
//  
//    
// 
//   inprom1 = EEPROM.read(i);
//   
//   inRprom1.concat(inprom1);
//}
//
//if(inRprom1.length()>0)
//{
//return inRprom1;
//
//}
//
//}
