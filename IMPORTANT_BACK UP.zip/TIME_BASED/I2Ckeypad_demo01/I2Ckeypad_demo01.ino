//
//    FILE: I2Ckeypad_demo01.ino
//  AUTHOR: Rob Tillaart
// PURPOSE: demo
//     URL: https://github.com/RobTillaart/I2CKeyPad
//
//  PCF8574
//    pin p0-p3 rows
//    pin p4-p7 columns
//  4x4 or smaller keypad.


#include "Wire.h"
#include "I2CKeyPad.h"
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// DS1302:  CE pin    -> Arduino Digital 2
//          I/O pin   -> Arduino Digital 3
//          SCLK pin  -> Arduino Digital 4
// LCD:     DB7       -> Arduino Digital 6
//          DB6       -> Arduino Digital 7
//          DB5       -> Arduino Digital 8
//          DB4       -> Arduino Digital 9
//          E         -> Arduino Digital 10
//          RS        -> Arduino Digital 11

#include <LiquidCrystal.h>
#include <DS1302.h>      // rtc(clock)

const int rs = 11, en = 10, d4 = 9, d5 = 8, d6 = 7, d7 = 6;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
//LiquidCrystal lcd(11, 10, 9, 8, 7, 6);

 // Setup LCD to 16x2 characters

// Init the DS1302
DS1302 rtc(2, 3, 4);

// Init a Time-data structure
//Time t;

//

const uint8_t KEYPAD_ADDRESS = 0x20; //38

I2CKeyPad keyPad(KEYPAD_ADDRESS);

uint32_t start, stop;
uint32_t lastKeyPressed = 0;
Time  t = rtc.getTime();

byte OnHour   = 1;  //  for the DEMONSTRATION consider,
byte OnMin    = 49;   //      12:00:05 - MORNING(light ON))
byte OnSec    =7;    //    & 12:00:15 - NIGHT  (light OFF) 
byte OffHour  = 12;
byte OffMin   = 0;
byte OffSec   =15;  
String dateing   = "16.03.2022"; 

int Relay = A5;
int sbutton = 10;
int pbutton = 11;
int mbutton = 12;
int selectb = A6;
int minusb = A7;
int plusb = 12;
 uint8_t index;
 
    String join="";
    int intjoin;
    String strhour="";
    String strmin="";
    String strsec="";
    int inthour;
    int intmin;
    int intsec;
    
void setup()
{
  Serial.begin(9600);
   lcd.begin(20, 4);
   //lcd.setCursor(0,0);
  intro();
  Serial.println(__FILE__);

  Wire.begin();
  Wire.setClock(400000);
  if (keyPad.begin() == false)
  {
    Serial.println("\nERROR: cannot communicate to keypad.\nPlease reboot.\n");
    while(1);
  }
}


void loop()
{
  String comp="135";
  uint32_t now = millis();
  char keys[] = "123A456B789C*0#D";  // N = NoKey, F = Fail

  if (now - lastKeyPressed >= 100)
  {
    start:
    lastKeyPressed = now;

    start = micros();
    if(keyPad.isPressed())
    {
     index = keyPad.getKey();
     delay(3);
     join.concat(String(keys[index]));
     delay(10);
     //Serial.println(keys[index]);
    // 
    //Serial.println(join);
    }
    


      if(join.length()>0 && join.length()<3)
      {
        //
        intjoin = join.toInt();
        //
       // 
       delay(30);
       // 
      //
      Serial.println(intjoin);
        //
       // if(isDigit(intjoin)) Serial.println(intjoin);
        //Serial.println(intjoin);
      if(intjoin==12)
      
      {
        //options();
        delay(10); Serial.println("* pressed");
       Serial.println("greater than 3");
       //keys[index]=empty;
       
       //
       //
       delay(50);
//      join="";
delay(4);
//      
//goto start;
      }

          
      }

  else

  {

//Serial.print("greter than 1 xter");
  join="";  
  }

//
//          if(join.length()>3)
//    {
//      delay(10);
//  
//     
//     // 
//     join="";
//    }
    stop = micros();
   // Serial.print("\t");
  
   
    delay(100);
  
   
   // 
   
    //join.concat(keys[index]);
    delay(100);

    
//    i++;
//   
   //}
  }
}


void intro()
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("TIME BASED APPLIANCE");
delay(100);
lcd.setCursor(4,2);
//lcd.print("APPLIANCE");
delay(100);
//lcd.setCursor(0,2);
lcd.print("CONTROLLER");
delay(1500);
lcd.clear();
lcd.setCursor(1,2);
lcd.print("PRESS * ");
delay(100);
//lcd.setCursor(0,1);
lcd.print("FOR OPTIONS");
delay(100);
  
}

// -- END OF FILE --
