

#include <Arduino.h>
#ifdef ESP32
#include <WiFi.h>
#include <AsyncTCP.h>
#elif defined(ESP8266)
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#endif
#include <ESPAsyncWebSrv.h>
#include "CF.h"

AsyncWebServer server(80);

//#define     SSI     "Habib"
//#define     PS      "company2020"

#define     SSI     "EMBEDDED2"
#define     PS      "Embedded@2020"
//Wi-Fi credentials
const char* ssid = SSI;
const char* password = PS;

//Initialize MQ sensors

const int MQ2_PIN = 34;
const int MQ7_PIN = 36;
const int MQ135_PIN = 35;

float MQ2R0 = 0.0;
float MQ7R0 = 0.0;
float MQ135R0 = 0.0;

// Variables for storing sensor voltages
float MQ2sensor_volt = 0.0;
float MQ7sensor_volt = 0.0;
float MQ135sensor_volt = 0.0;


void notFound(AsyncWebServerRequest *request) 
{
request->send(404, "text/plain", "Not found");
}


// Function to fetch real-time data from sensors and update webpage


void setup() 

{
  
Serial.begin(115200);
WiFi.mode(WIFI_STA);
Serial.print(body);
delay(3000);
WiFi.begin(ssid, password);
if (WiFi.waitForConnectResult() != WL_CONNECTED)
{
  
Serial.printf("WiFi Failed!\n");
return;
     
}

Serial.print("IP Address: ");
Serial.println(WiFi.localIP());

//server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
//{
//  
//request->send(200, "text/plain", "Hello, world");
//}
//);


server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) 
  
 
{
  
String html = "<!DOCTYPE html><html><head><title>Vehicle Emission Monitoring System</title>";
html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">";

html+="<style>";
html+="body {";

html+="background-color:#303642;";   //#303642 ; #6eaeee; #00A79D 
html+="} ";



html+="table {";
 
html+="font-family: arial, sans-serif;";
html+="border-collapse: collapse;";
html+="width: 100%;";
html+="}";

html+="td, th {";
html+="border: 1px solid #dddddd;";
html+="text-align: left;";
html+="padding: 8px;";
html+="}";

html+="tr:nth-child(even) {";
html+="background-color: #dddddd;";
html+="}";



html+= "h6{";

html+= "color: red";
html+= "margin-left: 40px";
html+= "}";
html+= "</style>";


html += "<script>";
html += "function fetchData() {";
html += "  fetch('/realtime-data').then(response => response.json()).then(data => {";
html += "    document.getElementById('mq2').innerHTML = 'MQ2 R0: ' + data.mq2;";
html += "    document.getElementById('mq7').innerHTML = 'MQ7 R0: ' + data.mq7;";
html += "    document.getElementById('mq135').innerHTML = 'MQ135 R0: ' + data.mq135;";
html += "  });";
html += "}";
html += "setInterval(fetchData, 2000);"; // Fetch data every 2 seconds
html += "fetchData();"; // Fetch data when the page loads initially
html += "</script></head><body style=\"margin: 0;font-size: 1rem;font-weight: 400;line-height: 1.5; olor: #212529 !important; \">";

html += "<div style=\" background-color:white; border: 5px groove white;text-align:center;width:53%;position: relative; box-sizing: border-box;min-height:400px;overflow: hidden; margin:0 auto; border-radius: 15px 15px 0px 0px; box-sizing: border-box; margin-top:30px\" >";
// main total body 
// #6e1f06

//BOTON UNIVERSITY

html += "<h1 style=\"color:yellow;margin:0px;text-align:center; border-bottom:17px solid #fff; border-radius:9px;background-color:#6e1f06; width:100%; min-height:50px;\">UNIVERSITY OF BOLTON</h1>";

// begin of top wrapper
html += "<div style=\" width: 100%;overflow:auto; margin:0 auto; padding 0px;\">" ; // #6e1f06 #00A79D  background-color:#6e1f06;


// student details
//border-top: 5px groove #00A79D ; border-bottom: 5px groove yellow;
// #fff; #303642  #00A79D
html += "<div style=\" background-color:#fff; float: left; padding:20px 5px;margin-right:3px; border:3px ridge yellow; border-radius:18px; width:35%; box-sizing: border-box; min-height:300px \">"; // student details section


html += "<p style=\" margin: 0 auto; padding:10px; 2px; text-align:left; \">";
html += "<span style=\" color:blue; font-size: 15px; font-weight:bolder; text-decoration:underline;\"> STUDENT:</span> <b>Farouq E. Usman </b> <br/>";


html += "<p style=\" margin: 0 auto; padding:10px; 2px; text-align:left; \">";
html += "<span style=\" color:blue; font-size: 15px; font-weight:bolder; text-decoration:underline;\"> SUPERVISOR:</span> <b>Dr Zhen Qiu</b><br/>";
html += "</p>";

html += "<p style=\" margin: 0 auto; padding:10px; 2px; text-align:left; \">";
html += "<span style=\" color:blue; font-size: 15px; font-weight:bolder; text-decoration:underline;\"> STUDENT ID:</span> <b>2205478</b><br/>";
html += "</p>";

html += "<p style=\" margin: 0 auto; padding:10px; 2px; text-align:left; \">";
html += "<span style=\" color:blue; font-size: 15px; font-weight:bolder; text-decoration:underline;\"> DATE: </span> <b> 01/08/2023</b> <br/> <br/>";
html += "</p>";

// student details

html += "</div> <br />";  // end of student details section

/////////////////////////////////////2//////////////////////////////////

//html += "<span style =  \" float: none; clear:left;\" />";

// vehicle emmission

html += "<div style=\"width:63%;padding:5px;  float:right; box-sizing: border-box; min-height:300px; text-align:justify;\">";  //begin of title
//black
html += "<h2 style=\"color: #00A79D ;text-align:left; background-color: ; padding-right:10px;\">Vehicle Emission Monitoring System</h2>";

html += "<p>A Vehicle Emission Monitoring System is a system designed to monitor and analyze the emissions produced by vehicles. It aims to track the amount of pollutants emitted by vehicles, such as carbon monoxide (CO), hydrocarbons (HC), nitrogen oxides (NOx), particulate matter (PM), and other harmful gases, to ensure compliance with environmental regulations and promote cleaner air.";
html += "</p>";
html += "<p>The Vehicle Emission Monitoring System plays a vital role in environmental protection and sustainable transportation.";
html +="It can be utilized for various purposes, including:";
html +="<li>Identifying high-emission vehicles and encouraging owners to take corrective actions,</li>";
html +="<li>Regulatory Compliance: Ensuring that vehicles meet emissions standards set by environmental authorities.Emission Reduction Programs:</li>";
html +="<li>Providing real-time emission data for immediate action when high-emission events are detected.</li>";
html +="</ul>";
html += "</p>";
//html += "<div style=\" color: black\">";
//html += "<h2>Gas Sensor Readings:</h2>";
//html += "<ul style=\"padding-top: 10px; list-style: none;\">";
//html += "<li id='mq2'>MQ2 R0: -</li>";
//html += "<li id='mq7'>MQ7 R0: -</li>";
//html += "<li id='mq135'>MQ135 R0: -</li>";
//html += "</ul>";
//html += "</div>";

html += "</div>"; // end of title-emmission
// end of top wrapper
html += "</div>" ;

// clear 

html += "<div style=\" clear:both; float:none; width:100%; border-bottom: solid 3px yellow; border-radius:3px; height:7px; background-color:#6e1f06;box-sizing: border-box;\">"; 
html += "</div>"; 

// THIS TABLE////////////////////////////////////

html += "<div style=\" width:100%; color:black; background-color:white; min-height:300px;box-sizing: border-box;\">";

//GAS DETAIL

html += "<div style=\" width:45%; background-color:white;border:2px solid yellow; border-radius:5px; min-height:200px;float:left; box-sizing: border-box;\">";
//html += "<p> something</p>";

html += "<table>";
html += "<h2 style=\"color:red; \">Detectable Gases</h2>";

//html += "<tr><th>GAS SENSOR</th> <th>DETECTABLE GASES</th></tr>";
html += " <tr> <td>MQ2</td><td>LPG, propane, butane, methane, alcohol, and hydrogen.</td></tr>";
html += "<tr><td>MQ7</td><td>carbon monoxide (CO)</td></tr>";
html += "<tr><td>MQ135</td><td>ammonia (NH3), nitrogen oxides (NOx), alcohol, benzene, smoke, and other volatile organic compounds (VOCs).</td></tr>";
html += "</table>";

html += "</div>"; //end of gas datasheet


//GAS MEASUREMENT start

html += "<div style=\" width:55%; background-color:white;border:2px solid yellow; border-radius:5px; min-height:200px; box-sizing: border-box; float:right;\">";
//html += "<p> something</p>";

html += "<h2 style=\"color:red; \">Gas Sensor Readings:</h2>";
html += "<table>";
html += "<tr><th>GAS SENSOR</th> <th>CURRENT VALUES</th></tr>";
html += " <tr> <td>MQ2</td><td id='mq2'>MQ2 R0: -</td></tr>";
html += "<tr><td>MQ7</td><td id='mq7'>MQ7 R0: -</td></tr>";
html += "<tr><td>MQ135</td><td  id='mq7'>MQ7 R0: -</td></tr>";

html += "</table>";

html += "</div>"; //end of gas measurement
html += "<div style=\"clear:both; float:none;\" >";

html += "</div>";

html += "</div>"; /// END OF MAIN TABLE

//html += "<div style=\" color: black\">";
//html += "<h2>Gas Sensor Readings:</h2>";
//html += "<ul style=\"padding-top: 10px; list-style: none;\">";
//html += "<li id='mq2'>MQ2 R0: -</li>";
//html += "<li id='mq7'>MQ7 R0: -</li>";
//html += "<li id='mq135'>MQ135 R0: -</li>";
//html += "</ul>";
//html += "</div>";

html+="</div>"; //  end main total body 

//background-color: #00A79D;

html += "<div style=\" clear:both; float:none; width:100%; border-bottom: solid 3px #303642; border-radius:1px; min-height:20px; background-color:#6e1f06;;\">"; 
html += "<span style=\" text-align: center; color: white; font-size: 15px; font-weight: bolder; margin-left:570px;\">&copy; University of Bolton 2023</span>";
html += "</div>"; 

html += "</body>";

 html +="</html>";

request->send(200, "text/html", html);
  
}

  
);


server.onNotFound(notFound);

server.begin();

}




void loop() {

//
server.begin();

server.on("/realtime-data", HTTP_GET, [](AsyncWebServerRequest *request) 
{
  
fetchData(); // Fetch real-time data
String data = "{\"mq2\":" + String(MQ2R0) + ", \"mq7\":" + String(MQ7R0) + ", \"mq135\":" + String(MQ135R0) + "}";
request->send(200, "application/json", data);

}
  
);

  // Print sensor values and parameters


delay(2000);

}




void fetchData() 
{
  
int MQ2sensorValue = 0;
int MQ7sensorValue = 0;
int MQ135sensorValue = 0;

// Get an average data by testing 100 times

  for (int x = 0; x < 100; x++) 
{
  
MQ2sensorValue = MQ2sensorValue + analogRead(MQ2_PIN);
MQ7sensorValue = MQ7sensorValue + analogRead(MQ7_PIN);
MQ135sensorValue = MQ135sensorValue + analogRead(MQ135_PIN);

}

MQ2sensor_volt = MQ2sensorValue / 100.0 / 1024.0 * 5.0;
MQ7sensor_volt = MQ7sensorValue / 100.0 / 1024.0 * 5.0;
MQ135sensor_volt = MQ135sensorValue / 100.0 / 1024.0 * 5.0;

float MQ2RS_air = (5.0 - MQ2sensor_volt) / MQ2sensor_volt; // omit *RL
float MQ7RS_air = (5.0 - MQ7sensor_volt) / MQ7sensor_volt;
float MQ135RS_air = (5.0 - MQ135sensor_volt) / MQ135sensor_volt;

// Check for division by zero and set default values if necessary
//MQ2R0 = 10; 
//
MQ2R0 = (MQ2RS_air == 0) ? 0 : MQ2RS_air / 10.0;
MQ7R0 = (MQ7RS_air == 0) ? 0 : MQ7RS_air / 10.0;
MQ135R0 = (MQ135RS_air == 0) ? 0 : MQ135RS_air / 10.0;


Serial.print("MQ2sensor_volt = ");
Serial.print(MQ2sensor_volt);

Serial.print("MQ7sensor_volt = ");
Serial.print(MQ7sensor_volt);

Serial.print("MQ135sensor_volt = ");
Serial.print(MQ135sensor_volt);

Serial.print("MQ2R0 = ");
Serial.println(MQ2R0);

Serial.print("MQ7R0 = ");
Serial.println(MQ7R0);

Serial.print("MQ135R0 = ");
Serial.println(MQ135R0);
delay(300);
} //fe
