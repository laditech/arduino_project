//String body = "re";
//style=\" \"
//   box-sizing: border-box;
//String tag = "";
//body += "<div style=\"border: 2px groove blue;text-align:center;\" >";

/*
 * 
 * 
 *     margin: 0;
    font-family: "Source Sans Pro",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529 !important;
 */
