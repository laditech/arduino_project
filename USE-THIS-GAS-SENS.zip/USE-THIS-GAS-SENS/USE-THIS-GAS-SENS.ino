#include <WiFi.h>
//
#include <ESPAsyncWebSrv.h>
//#include <ESPAsyncWebServer.h>

const char* ssid = "MYESP32";
const char* password = "ESP_32";

AsyncWebServer server(80);

// Initialize MQ sensors

const int MQ2_PIN = 34;
const int MQ7_PIN = 36;
const int MQ135_PIN = 35;

// variable for storing the potentiometer value
int MQ2Value = 0;
int MQ7Value = 0;
int MQ135Value = 0;

void setup() {
  Serial.begin(115200);
  
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  
  Serial.println("Connected to WiFi");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  
  // Route for root page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    String html = "<html><body>";
    
    html += "<h1>Vehicle Emission Monitoring System</h1>";
    html += "<h2>Gas Sensor Readings:</h2>";
    html += "<ul>";
//    html += "<li>MQ2: " + " " + "</li>";
//    html += "<li>MQ7: " + " this " + "</li>";
//    html += "<li>MQ135: " + " " + "</li>";
    html += "</ul>";
    
    html += "</body></html>";
    
    request->send(200, "text/html", html);
  });
  
  // Start server
  server.begin();
}

void loop() {
  // Read sensor data
  
MQ2Value = analogRead(MQ2_PIN);
delay(300);
MQ7Value = analogRead(MQ7_PIN);
delay(300);
MQ135Value = analogRead(MQ135_PIN);
delay(300);
//
//Serial.println("Analog value of MQ2: ");
//Serial.print(MQ2Value);
delay(100);

  
  Serial.print("MQ2Value: ");
  Serial.println(MQ2Value);
 // Serial.println(mq2Value);
  
  Serial.print("MQ7Value: ");
    Serial.println(MQ7Value);
 // Serial.println(mq7Value);
  
  Serial.print("MQ135Value: ");
    Serial.println(MQ135Value);
 // Serial.println(mq135Value);
  
  delay(3000); // wait for 3 seeconds
}
